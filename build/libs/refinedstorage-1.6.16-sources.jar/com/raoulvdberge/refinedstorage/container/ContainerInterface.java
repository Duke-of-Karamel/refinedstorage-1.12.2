package com.raoulvdberge.refinedstorage.container;

import com.raoulvdberge.refinedstorage.container.slot.SlotOutput;
import com.raoulvdberge.refinedstorage.container.slot.filter.SlotFilter;
import com.raoulvdberge.refinedstorage.tile.TileInterface;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.items.SlotItemHandler;

public class ContainerInterface extends ContainerBase {
    public ContainerInterface(TileInterface tile, EntityPlayer player) {
        super(tile, player);

        for (int i = 0; i < 9; ++i) {
            func_75146_a(new SlotItemHandler(tile.getNode().getImportItems(), i, 8 + (18 * i), 20));
        }

        for (int i = 0; i < 9; ++i) {
            func_75146_a(new SlotFilter(tile.getNode().getExportFilterItems(), i, 8 + (18 * i), 54, SlotFilter.FILTER_ALLOW_SIZE));
        }

        for (int i = 0; i < 9; ++i) {
            func_75146_a(new SlotOutput(tile.getNode().getExportItems(), i, 8 + (18 * i), 100));
        }

        for (int i = 0; i < 4; ++i) {
            func_75146_a(new SlotItemHandler(tile.getNode().getUpgrades(), i, 187, 6 + (i * 18)));
        }

        addPlayerInventory(8, 134);

        transferManager.addBiTransfer(player.field_71071_by, tile.getNode().getUpgrades());
        transferManager.addBiTransfer(player.field_71071_by, tile.getNode().getImportItems());
        transferManager.addTransfer(tile.getNode().getExportItems(), player.field_71071_by);
    }
}
