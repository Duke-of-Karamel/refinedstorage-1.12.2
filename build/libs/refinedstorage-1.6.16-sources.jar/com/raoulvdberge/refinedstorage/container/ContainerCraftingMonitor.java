package com.raoulvdberge.refinedstorage.container;

import com.raoulvdberge.refinedstorage.RS;
import com.raoulvdberge.refinedstorage.api.autocrafting.ICraftingManager;
import com.raoulvdberge.refinedstorage.api.autocrafting.craftingmonitor.ICraftingMonitorListener;
import com.raoulvdberge.refinedstorage.network.MessageCraftingMonitorElements;
import com.raoulvdberge.refinedstorage.tile.craftingmonitor.ICraftingMonitor;
import com.raoulvdberge.refinedstorage.tile.craftingmonitor.TileCraftingMonitor;
import com.raoulvdberge.refinedstorage.tile.craftingmonitor.WirelessCraftingMonitor;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

import javax.annotation.Nullable;

public class ContainerCraftingMonitor extends ContainerBase implements ICraftingMonitorListener {
    private ICraftingMonitor craftingMonitor;
    private boolean addedListener;

    public ContainerCraftingMonitor(ICraftingMonitor craftingMonitor, @Nullable TileCraftingMonitor craftingMonitorTile, EntityPlayer player) {
        super(craftingMonitorTile, player);

        this.craftingMonitor = craftingMonitor;
    }

    @Override
    public void func_75142_b() {
        super.func_75142_b();

        ICraftingManager manager = craftingMonitor.getCraftingManager();
        if (!getPlayer().field_70170_p.field_72995_K) {
            if (manager != null && !addedListener) {
                manager.addListener(this);

                this.addedListener = true;
            } else if (manager == null && addedListener) {
                this.addedListener = false;
            }
        }
    }

    @Override
    public void func_75134_a(EntityPlayer player) {
        super.func_75134_a(player);

        ICraftingManager manager = craftingMonitor.getCraftingManager();
        if (!player.func_130014_f_().field_72995_K && manager != null && addedListener) {
            manager.removeListener(this);
        }
    }

    public ICraftingMonitor getCraftingMonitor() {
        return craftingMonitor;
    }

    @Override
    public ItemStack func_82846_b(EntityPlayer player, int index) {
        ItemStack stack = ItemStack.field_190927_a;

        Slot slot = func_75139_a(index);

        if (slot.func_75216_d()) {
            stack = slot.func_75211_c();

            if (index < 4) {
                if (!func_75135_a(stack, 4, field_75151_b.size(), false)) {
                    return ItemStack.field_190927_a;
                }
            } else if (!func_75135_a(stack, 0, 4, false)) {
                return ItemStack.field_190927_a;
            }

            if (stack.func_190916_E() == 0) {
                slot.func_75215_d(ItemStack.field_190927_a);
            } else {
                slot.func_75218_e();
            }
        }

        return stack;
    }

    @Override
    protected int getDisabledSlotNumber() {
        return craftingMonitor.getSlotId();
    }

    @Override
    public void onAttached() {
        onChanged();
    }

    @Override
    public void onChanged() {
        RS.INSTANCE.network.sendTo(new MessageCraftingMonitorElements(craftingMonitor), (EntityPlayerMP) getPlayer());
    }
}
