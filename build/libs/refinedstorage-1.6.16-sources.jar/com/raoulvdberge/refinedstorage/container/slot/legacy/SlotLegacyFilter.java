package com.raoulvdberge.refinedstorage.container.slot.legacy;


import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;

import javax.annotation.Nonnull;

public class SlotLegacyFilter extends SlotLegacyBase {
    public SlotLegacyFilter(IInventory inventory, int inventoryIndex, int x, int y) {
        super(inventory, inventoryIndex, x, y);
    }

    @Override
    public boolean func_82869_a(EntityPlayer player) {
        return false;
    }

    @Override
    public boolean func_75214_a(ItemStack stack) {
        return true;
    }

    @Override
    public void func_75215_d(@Nonnull ItemStack stack) {
        if (!stack.func_190926_b()) {
            stack.func_190920_e(1);
        }

        super.func_75215_d(stack);
    }
}
