package com.raoulvdberge.refinedstorage.container.slot;

import net.minecraft.item.ItemStack;
import net.minecraftforge.items.IItemHandler;

import javax.annotation.Nonnull;

public class SlotDisabled extends SlotBase {
    public SlotDisabled(IItemHandler itemHandler, int inventoryIndex, int x, int y) {
        super(itemHandler, inventoryIndex, x, y);
    }

    @Override
    public boolean func_75214_a(@Nonnull ItemStack stack) {
        return false;
    }
}
