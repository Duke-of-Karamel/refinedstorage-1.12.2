package com.raoulvdberge.refinedstorage.container.slot.filter;

import com.raoulvdberge.refinedstorage.container.slot.SlotBase;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.common.IPlantable;
import net.minecraftforge.items.IItemHandler;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class SlotFilter extends SlotBase {
    public static final int FILTER_ALLOW_SIZE = 1;
    public static final int FILTER_ALLOW_BLOCKS = 2;

    private int flags = 0;

    public SlotFilter(IItemHandler handler, int inventoryIndex, int x, int y, int flags) {
        super(handler, inventoryIndex, x, y);

        this.flags = flags;
    }

    public SlotFilter(IItemHandler handler, int inventoryIndex, int x, int y) {
        this(handler, inventoryIndex, x, y, 0);
    }

    @Override
    public boolean func_75214_a(@Nonnull ItemStack stack) {
        if (super.func_75214_a(stack)) {
            if (isBlockAllowed()) {
                return stack.func_77973_b() instanceof ItemBlock || stack.func_77973_b() instanceof ItemBlockSpecial || stack.func_77973_b() instanceof IPlantable || stack.func_77973_b() instanceof ItemSkull;
            }

            return true;
        }

        return false;
    }

    @Override
    public void func_75215_d(@Nonnull ItemStack stack) {
        if (!stack.func_190926_b() && !isSizeAllowed()) {
            stack.func_190920_e(1);
        }

        super.func_75215_d(stack);
    }

    public boolean isSizeAllowed() {
        return (flags & FILTER_ALLOW_SIZE) == FILTER_ALLOW_SIZE;
    }

    public boolean isBlockAllowed() {
        return (flags & FILTER_ALLOW_BLOCKS) == FILTER_ALLOW_BLOCKS;
    }

    @Nullable
    public static IBlockState getBlockState(IBlockAccess world, BlockPos pos, @Nullable ItemStack stack) {
        if (stack != null) {
            Item item = stack.func_77973_b();

            if (item instanceof ItemBlockSpecial) {
                return ((ItemBlockSpecial) item).getBlock().func_176223_P();
            } else if (item instanceof ItemBlock) {
                return (((ItemBlock) item).func_179223_d()).func_176223_P();
            } else if (item instanceof IPlantable) {
                return ((IPlantable) item).getPlant(world, pos);
            } else if (item instanceof ItemSkull) {
                return Blocks.field_150465_bP.func_176223_P();
            }
        }

        return null;
    }
}
