package com.raoulvdberge.refinedstorage.container.slot.grid;

import com.raoulvdberge.refinedstorage.api.network.grid.IGrid;
import com.raoulvdberge.refinedstorage.container.ContainerGrid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.SlotCrafting;
import net.minecraft.item.ItemStack;

import javax.annotation.Nonnull;

public class SlotGridCraftingResult extends SlotCrafting {
    private ContainerGrid container;
    private IGrid grid;

    public SlotGridCraftingResult(ContainerGrid container, EntityPlayer player, IGrid grid, int inventoryIndex, int x, int y) {
        super(player, grid.getCraftingMatrix(), grid.getCraftingResult(), inventoryIndex, x, y);

        this.container = container;
        this.grid = grid;
    }

    @Override
    @Nonnull
    public ItemStack func_190901_a(EntityPlayer player, @Nonnull ItemStack stack) {
        func_75208_c(stack);

        if (!player.func_130014_f_().field_72995_K) {
            grid.onCrafted(player);
        }

        return ItemStack.field_190927_a;
    }
}
