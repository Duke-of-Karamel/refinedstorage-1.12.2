package com.raoulvdberge.refinedstorage.container;

import com.raoulvdberge.refinedstorage.apiimpl.autocrafting.CraftingPattern;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.NetworkNodeCrafter;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.NetworkNodeCrafterManager;
import com.raoulvdberge.refinedstorage.container.slot.SlotCrafterManager;
import com.raoulvdberge.refinedstorage.gui.IResizableDisplay;
import com.raoulvdberge.refinedstorage.gui.grid.filtering.GridFilterParser;
import com.raoulvdberge.refinedstorage.gui.grid.stack.GridStackItem;
import com.raoulvdberge.refinedstorage.gui.grid.stack.IGridStack;
import com.raoulvdberge.refinedstorage.inventory.item.ItemHandlerBase;
import com.raoulvdberge.refinedstorage.item.ItemPattern;
import com.raoulvdberge.refinedstorage.tile.TileCrafterManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraftforge.items.IItemHandlerModifiable;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

public class ContainerCrafterManager extends ContainerBase {
    public class CrafterManagerListener implements IContainerListener {
        private EntityPlayerMP base;
        private boolean receivedContainerData;

        public CrafterManagerListener(EntityPlayerMP base) {
            this.base = base;
        }

        public EntityPlayerMP getPlayer() {
            return base;
        }

        @Override
        public void func_71110_a(Container container, NonNullList<ItemStack> items) {
            if (receivedContainerData) {
                base.func_71110_a(container, items);
            }
        }

        @Override
        public void func_71111_a(Container container, int slotInd, ItemStack stack) {
            if (receivedContainerData) {
                base.func_71111_a(container, slotInd, stack);
            }
        }

        public void setReceivedContainerData() {
            receivedContainerData = true;
        }

        @Override
        public void func_71112_a(Container container, int varToUpdate, int newValue) {
            base.func_71112_a(container, varToUpdate, newValue);
        }

        @Override
        public void func_175173_a(Container container, IInventory inventory) {
            base.func_175173_a(container, inventory);
        }
    }

    private IResizableDisplay display;
    private NetworkNodeCrafterManager crafterManager;
    private Map<String, Integer> containerData;
    private Map<String, IItemHandlerModifiable> dummyInventories = new HashMap<>();
    private Map<String, Integer> headings = new HashMap<>();
    private int rows;

    @Override
    public void func_75132_a(IContainerListener listener) {
        if (listener instanceof EntityPlayerMP) {
            listener = new CrafterManagerListener((EntityPlayerMP) listener);
        }

        super.func_75132_a(listener);
    }

    public List<IContainerListener> getListeners() {
        return field_75149_d;
    }

    public ContainerCrafterManager(TileCrafterManager crafterManager, EntityPlayer player, IResizableDisplay display) {
        super(crafterManager, player);

        this.display = display;
        this.crafterManager = crafterManager.getNode();

        if (!player.field_70170_p.field_72995_K) {
            addPlayerInventory(8, display.getYPlayerInventory());

            if (crafterManager.getNode().getNetwork() != null) {
                for (Map.Entry<String, List<IItemHandlerModifiable>> entry : crafterManager.getNode().getNetwork().getCraftingManager().getNamedContainers().entrySet()) {
                    for (IItemHandlerModifiable handler : entry.getValue()) {
                        for (int i = 0; i < handler.getSlots(); ++i) {
                            func_75146_a(new SlotCrafterManager(handler, i, 0, 0, true, display, this.crafterManager));
                        }
                    }
                }
            }
        }
    }

    public void initSlots(@Nullable Map<String, Integer> newContainerData) {
        if (newContainerData == null) { // We resized
            if (containerData == null) { // No container data received yet, do nothing..
                return;
            }
        } else {
            containerData = newContainerData; // Received container data

            dummyInventories.clear();
        }

        this.field_75151_b.clear();
        this.field_75153_a.clear();
        this.headings.clear();

        rows = 0;

        addPlayerInventory(8, display.getYPlayerInventory());

        int y = 19 + 18 - display.getCurrentOffset() * 18;
        int x = 8;

        List<Predicate<IGridStack>> filters = GridFilterParser.getFilters(null, display.getSearchFieldText(), Collections.emptyList());

        for (Map.Entry<String, Integer> category : containerData.entrySet()) {
            IItemHandlerModifiable dummy;

            if (newContainerData == null) { // We're only resizing, get the previous inventory...
                dummy = dummyInventories.get(category.getKey());
            } else {
                dummyInventories.put(category.getKey(), dummy = new ItemHandlerBase(category.getValue()) {
                    @Override
                    public int getSlotLimit(int slot) {
                        return 1;
                    }

                    @Nonnull
                    @Override
                    public ItemStack insertItem(int slot, @Nonnull ItemStack stack, boolean simulate) {
                        if (NetworkNodeCrafter.isValidPatternInSlot(getPlayer().func_130014_f_(), stack)) {
                            return super.insertItem(slot, stack, simulate);
                        }

                        return stack;
                    }
                });
            }

            boolean foundItemsInCategory = false;

            int yHeading = y - 19;

            int slotFound = 0;
            for (int slot = 0; slot < category.getValue(); ++slot) {
                boolean visible = true;

                if (!display.getSearchFieldText().trim().isEmpty()) {
                    ItemStack stack = dummy.getStackInSlot(slot);

                    if (stack.func_190926_b()) {
                        visible = false;
                    } else {
                        CraftingPattern pattern = ItemPattern.getPatternFromCache(crafterManager.getWorld(), stack);

                        visible = false;

                        for (ItemStack output : pattern.getOutputs()) {
                            GridStackItem outputConverted = new GridStackItem(output);

                            for (Predicate<IGridStack> filter : filters) {
                                if (filter.test(outputConverted)) {
                                    visible = true;
                                    break;
                                }
                            }
                        }
                    }
                }

                func_75146_a(new SlotCrafterManager(dummy, slot, x, y, visible, display, crafterManager));

                if (visible) {
                    foundItemsInCategory = true;

                    x += 18;

                    // Don't increase y level if we are on our last slot row (otherwise we do y += 18 * 3)
                    if ((slotFound + 1) % 9 == 0 && slot + 1 < category.getValue()) {
                        x = 8;
                        y += 18;
                        rows++;
                    }

                    slotFound++;
                }
            }

            if (foundItemsInCategory) {
                headings.put(category.getKey(), yHeading);

                x = 8;
                y += 18 * 2;
                rows += 2; // Heading and first row
            }
        }
    }

    public Map<String, Integer> getHeadings() {
        return headings;
    }

    public int getRows() {
        return rows;
    }

    @Override
    public ItemStack func_82846_b(EntityPlayer player, int index) {
        ItemStack stack = ItemStack.field_190927_a;

        Slot slot = func_75139_a(index);

        if (slot.func_75216_d()) {
            stack = slot.func_75211_c();

            if (index < 9 * 4) {
                if (!func_75135_a(stack, 9 * 4, field_75151_b.size(), false)) {
                    return ItemStack.field_190927_a;
                }
            } else if (!func_75135_a(stack, 0, 9 * 4, false)) {
                return ItemStack.field_190927_a;
            }

            if (stack.func_190916_E() == 0) {
                slot.func_75215_d(ItemStack.field_190927_a);
            } else {
                slot.func_75218_e();
            }
        }

        return stack;
    }
}
