package com.raoulvdberge.refinedstorage.container;

import com.raoulvdberge.refinedstorage.container.slot.filter.SlotFilter;
import com.raoulvdberge.refinedstorage.tile.TileStorageMonitor;
import net.minecraft.entity.player.EntityPlayer;

public class ContainerStorageMonitor extends ContainerBase {
    public ContainerStorageMonitor(TileStorageMonitor storageMonitor, EntityPlayer player) {
        super(storageMonitor, player);

        func_75146_a(new SlotFilter(storageMonitor.getNode().getItemFilters(), 0, 80, 20));

        addPlayerInventory(8, 55);

        transferManager.addItemFilterTransfer(player.field_71071_by, storageMonitor.getNode().getItemFilters());
    }
}
