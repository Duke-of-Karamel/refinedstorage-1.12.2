package com.raoulvdberge.refinedstorage.gui;

import com.raoulvdberge.refinedstorage.RS;
import com.raoulvdberge.refinedstorage.api.util.IComparer;
import com.raoulvdberge.refinedstorage.api.util.IFilter;
import com.raoulvdberge.refinedstorage.container.ContainerFilter;
import com.raoulvdberge.refinedstorage.gui.control.SideButtonFilterType;
import com.raoulvdberge.refinedstorage.item.ItemFilter;
import com.raoulvdberge.refinedstorage.network.MessageFilterUpdate;
import com.raoulvdberge.refinedstorage.tile.config.IType;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.client.config.GuiCheckBox;

import java.io.IOException;

public class GuiFilter extends GuiBase {
    private ItemStack stack;

    private int compare;
    private int mode;
    private boolean modFilter;
    private String name;
    private int type;

    private GuiCheckBox compareDamage;
    private GuiCheckBox compareNbt;
    private GuiCheckBox toggleModFilter;
    private GuiButton toggleMode;
    private GuiTextField nameField;

    public GuiFilter(ContainerFilter container) {
        super(container, 176, 231);

        this.stack = container.getStack();

        this.compare = ItemFilter.getCompare(container.getStack());
        this.mode = ItemFilter.getMode(container.getStack());
        this.modFilter = ItemFilter.isModFilter(container.getStack());
        this.name = ItemFilter.getName(container.getStack());
        this.type = ItemFilter.getType(container.getStack());
    }

    @Override
    public void init(int x, int y) {
        compareNbt = addCheckBox(x + 7, y + 77, t("gui.refinedstorage:filter.compare_nbt"), (compare & IComparer.COMPARE_NBT) == IComparer.COMPARE_NBT);
        compareDamage = addCheckBox(x + 7 + compareNbt.func_146117_b() + 4, y + 77, t("gui.refinedstorage:filter.compare_damage"), (compare & IComparer.COMPARE_DAMAGE) == IComparer.COMPARE_DAMAGE);
        compareDamage.field_146125_m = type == IType.ITEMS;

        toggleModFilter = addCheckBox(0, y + 71 + 25, t("gui.refinedstorage:filter.mod_filter"), modFilter);
        toggleMode = addButton(x + 7, y + 71 + 21, 0, 20, "");

        updateModeButton(mode);

        nameField = new GuiTextField(0, field_146289_q, x + 34, y + 121, 137 - 6, field_146289_q.field_78288_b);
        nameField.func_146180_a(name);
        nameField.func_146185_a(false);
        nameField.func_146189_e(true);
        nameField.func_146205_d(true);
        nameField.func_146195_b(false);
        nameField.func_146193_g(16777215);

        addSideButton(new SideButtonFilterType(this));
    }

    private void updateModeButton(int mode) {
        String text = mode == IFilter.MODE_WHITELIST ? t("sidebutton.refinedstorage:mode.whitelist") : t("sidebutton.refinedstorage:mode.blacklist");

        toggleMode.func_175211_a(field_146289_q.func_78256_a(text) + 12);
        toggleMode.field_146126_j = text;
        toggleModFilter.field_146128_h = toggleMode.field_146128_h + toggleMode.func_146117_b() + 4;
    }

    @Override
    public void update(int x, int y) {
    }

    @Override
    public void drawBackground(int x, int y, int mouseX, int mouseY) {
        bindTexture("gui/filter.png");

        drawTexture(x, y, 0, 0, screenWidth, screenHeight);

        nameField.func_146194_f();
    }

    @Override
    public void drawForeground(int mouseX, int mouseY) {
        drawString(7, 7, t("gui.refinedstorage:filter"));
        drawString(7, 137, t("container.inventory"));
    }

    @Override
    protected void func_73869_a(char character, int keyCode) throws IOException {
        if (!func_146983_a(keyCode) && nameField.func_146201_a(character, keyCode)) {
            sendUpdate();
        } else {
            super.func_73869_a(character, keyCode);
        }
    }

    @Override
    public void func_73864_a(int mouseX, int mouseY, int clickedButton) throws IOException {
        super.func_73864_a(mouseX, mouseY, clickedButton);

        nameField.func_146192_a(mouseX, mouseY, clickedButton);
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        super.func_146284_a(button);

        if (button == compareDamage) {
            compare ^= IComparer.COMPARE_DAMAGE;
        } else if (button == compareNbt) {
            compare ^= IComparer.COMPARE_NBT;
        } else if (button == toggleMode) {
            mode = mode == IFilter.MODE_WHITELIST ? IFilter.MODE_BLACKLIST : IFilter.MODE_WHITELIST;

            updateModeButton(mode);
        } else if (button == toggleModFilter) {
            modFilter = !modFilter;
        }

        sendUpdate();
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;

        ItemFilter.setType(stack, type);

        compareDamage.field_146125_m = type == IType.ITEMS;
    }

    public void sendUpdate() {
        RS.INSTANCE.network.sendToServer(new MessageFilterUpdate(compare, mode, modFilter, nameField.func_146179_b(), type));
    }
}
