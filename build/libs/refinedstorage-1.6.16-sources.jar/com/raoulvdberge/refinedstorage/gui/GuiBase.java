package com.raoulvdberge.refinedstorage.gui;

import com.raoulvdberge.refinedstorage.RS;
import com.raoulvdberge.refinedstorage.api.render.IElementDrawer;
import com.raoulvdberge.refinedstorage.api.render.IElementDrawers;
import com.raoulvdberge.refinedstorage.apiimpl.API;
import com.raoulvdberge.refinedstorage.container.slot.filter.SlotFilter;
import com.raoulvdberge.refinedstorage.container.slot.filter.SlotFilterFluid;
import com.raoulvdberge.refinedstorage.gui.control.Scrollbar;
import com.raoulvdberge.refinedstorage.gui.control.SideButton;
import com.raoulvdberge.refinedstorage.integration.jei.IntegrationJEI;
import com.raoulvdberge.refinedstorage.integration.jei.RecipeTransferHandlerGrid;
import com.raoulvdberge.refinedstorage.util.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.client.config.GuiCheckBox;
import net.minecraftforge.fml.client.config.GuiUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.IOException;
import java.util.*;
import java.util.function.Consumer;

public abstract class GuiBase extends GuiContainer {
    private static final Map<String, ResourceLocation> TEXTURE_CACHE = new HashMap<>();
    private static final Map<Class, Queue<Consumer>> RUNNABLES = new HashMap<>();

    public static final RenderUtils.FluidRenderer FLUID_RENDERER = new RenderUtils.FluidRenderer(-1, 16, 16);

    public class ElementDrawers implements IElementDrawers {
        private IElementDrawer<FluidStack> fluidDrawer = (x, y, element) -> FLUID_RENDERER.draw(GuiBase.this.field_146297_k, x, y, element);

        @Override
        public IElementDrawer<ItemStack> getItemDrawer() {
            return GuiBase.this::drawItem;
        }

        @Override
        public IElementDrawer<FluidStack> getFluidDrawer() {
            return fluidDrawer;
        }

        @Override
        public IElementDrawer<String> getStringDrawer() {
            return GuiBase.this::drawString;
        }

        @Override
        public FontRenderer getFontRenderer() {
            return field_146289_q;
        }
    }

    private int lastButtonId;
    private int lastSideButtonY;

    private String hoveringFluid = null;

    protected int screenWidth;
    protected int screenHeight;

    protected Scrollbar scrollbar;

    private boolean initializing;

    public GuiBase(Container container, int screenWidth, int screenHeight) {
        super(container);

        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.field_146999_f = screenWidth;
        this.field_147000_g = screenHeight;
    }

    private void runRunnables() {
        Queue<Consumer> queue = RUNNABLES.get(getClass());

        if (queue != null && !queue.isEmpty()) {
            Consumer callback;
            while ((callback = queue.poll()) != null) {
                callback.accept(this);
            }
        }

        queue = RUNNABLES.get(GuiContainer.class);

        if (queue != null && !queue.isEmpty()) {
            Consumer callback;
            while ((callback = queue.poll()) != null) {
                callback.accept(this);
            }
        }
    }

    public int getScreenWidth() {
        return screenWidth;
    }

    public int getScreenHeight() {
        return screenHeight;
    }

    public Scrollbar getScrollbar() {
        return scrollbar;
    }

    public boolean isMouseOverSlotPublic(Slot slot, int mx, int my) {
        return this.func_146978_c(slot.field_75223_e, slot.field_75221_f, 16, 16, mx, my);
    }

    @Override
    public void func_73866_w_() {
        if (initializing) { // Fix double initialize because of runRunnables
            return;
        }

        initializing = true;

        Keyboard.enableRepeatEvents(true);

        calcHeight();

        super.func_73866_w_();

        if (!field_146292_n.isEmpty()) {
            field_146292_n.removeIf(b -> !b.getClass().getName().contains("net.blay09.mods.craftingtweaks")); // Prevent crafting tweaks buttons from resetting
        }

        lastButtonId = 0;
        lastSideButtonY = getSideButtonYStart();

        init(field_147003_i, field_147009_r);

        runRunnables();

        initializing = false;
    }

    @Override
    public void func_146281_b() {
        super.func_146281_b();
        Keyboard.enableRepeatEvents(false);
    }

    protected void calcHeight() {
        // NO OP
    }

    protected int getSideButtonYStart() {
        return 6;
    }

    @Override
    public void func_73876_c() {
        super.func_73876_c();

        runRunnables();

        update(field_147003_i, field_147009_r);
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();

        try {
            super.func_73863_a(mouseX, mouseY, partialTicks);
        } catch (Exception e) {
            // NO OP: Prevent a MC crash (see #1483)
        }

        func_191948_b(mouseX, mouseY);

        // Prevent accidental scrollbar click after clicking recipe transfer button
        if (scrollbar != null && (!IntegrationJEI.isLoaded() || System.currentTimeMillis() - RecipeTransferHandlerGrid.LAST_TRANSFER > RecipeTransferHandlerGrid.TRANSFER_SCROLL_DELAY_MS)) {
            scrollbar.update(this, mouseX - field_147003_i, mouseY - field_147009_r);
        }
    }

    @Override
    protected void func_146976_a(float renderPartialTicks, int mouseX, int mouseY) {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);

        drawBackground(field_147003_i, field_147009_r, mouseX, mouseY);

        this.hoveringFluid = null;

        for (int i = 0; i < field_147002_h.field_75151_b.size(); ++i) {
            Slot slot = field_147002_h.field_75151_b.get(i);

            if (slot.func_111238_b() && slot instanceof SlotFilterFluid) {
                FluidStack stack = ((SlotFilterFluid) slot).getFluidInventory().getFluid(slot.getSlotIndex());

                if (stack != null) {
                    FLUID_RENDERER.draw(field_146297_k, field_147003_i + slot.field_75223_e, field_147009_r + slot.field_75221_f, stack);

                    if (((SlotFilterFluid) slot).isSizeAllowed()) {
                        drawQuantity(field_147003_i + slot.field_75223_e, field_147009_r + slot.field_75221_f, API.instance().getQuantityFormatter().formatInBucketForm(stack.amount));

                        GL11.glDisable(GL11.GL_LIGHTING);
                    }

                    if (inBounds(field_147003_i + slot.field_75223_e, field_147009_r + slot.field_75221_f, 17, 17, mouseX, mouseY)) {
                        this.hoveringFluid = stack.getLocalizedName();
                    }
                }
            }
        }

        if (scrollbar != null) {
            GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);

            scrollbar.draw(this);
        }
    }

    @Override
    protected void func_146979_b(int mouseX, int mouseY) {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);

        mouseX -= field_147003_i;
        mouseY -= field_147009_r;

        String sideButtonTooltip = null;

        for (int i = 0; i < field_146292_n.size(); ++i) {
            GuiButton button = field_146292_n.get(i);

            if (button instanceof SideButton && ((SideButton) button).isHovered()) {
                sideButtonTooltip = ((SideButton) button).getTooltip();
            }
        }

        drawForeground(mouseX, mouseY);

        if (sideButtonTooltip != null || hoveringFluid != null) {
            drawTooltip(mouseX, mouseY, sideButtonTooltip != null ? sideButtonTooltip : hoveringFluid);
        }
    }

    @Override
    protected void func_184098_a(Slot slot, int slotId, int mouseButton, ClickType type) {
        boolean valid = type != ClickType.QUICK_MOVE && Minecraft.func_71410_x().field_71439_g.field_71071_by.func_70445_o().func_190926_b();

        if (valid && slot instanceof SlotFilter && slot.func_111238_b() && ((SlotFilter) slot).isSizeAllowed()) {
            if (!slot.func_75211_c().func_190926_b()) {
                FMLClientHandler.instance().showGuiScreen(new GuiAmount(
                    (GuiBase) Minecraft.func_71410_x().field_71462_r,
                    Minecraft.func_71410_x().field_71439_g,
                    slot.field_75222_d,
                    slot.func_75211_c(),
                    slot.func_75219_a()
                ));
            }
        } else if (valid && slot instanceof SlotFilterFluid && slot.func_111238_b() && ((SlotFilterFluid) slot).isSizeAllowed()) {
            FluidStack stack = ((SlotFilterFluid) slot).getFluidInventory().getFluid(slot.getSlotIndex());

            if (stack != null) {
                FMLClientHandler.instance().showGuiScreen(new GuiFluidAmount(
                    (GuiBase) Minecraft.func_71410_x().field_71462_r,
                    Minecraft.func_71410_x().field_71439_g,
                    slot.field_75222_d,
                    stack,
                    ((SlotFilterFluid) slot).getFluidInventory().getMaxAmount()
                ));
            } else {
                super.func_184098_a(slot, slotId, mouseButton, type);
            }
        } else {
            super.func_184098_a(slot, slotId, mouseButton, type);
        }
    }

    @Override
    public void func_146274_d() throws IOException {
        super.func_146274_d();

        int d = Mouse.getEventDWheel();

        if (scrollbar != null && d != 0) {
            scrollbar.wheel(d);
        }
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        super.func_146284_a(button);

        if (button instanceof SideButton) {
            ((SideButton) button).actionPerformed();
        }
    }

    public GuiCheckBox addCheckBox(int x, int y, String text, boolean checked) {
        GuiCheckBox checkBox = new GuiCheckBox(lastButtonId++, x, y, text, checked);

        field_146292_n.add(checkBox);

        return checkBox;
    }

    public GuiButton addButton(int x, int y, int w, int h, String text) {
        return addButton(x, y, w, h, text, true, true);
    }

    public GuiButton addButton(int x, int y, int w, int h, String text, boolean enabled, boolean visible) {
        GuiButton button = new GuiButton(lastButtonId++, x, y, w, h, text);
        button.field_146124_l = enabled;
        button.field_146125_m = visible;

        field_146292_n.add(button);

        return button;
    }

    public SideButton addSideButton(SideButton button) {
        button.field_146127_k = lastButtonId++;
        button.field_146128_h = field_147003_i + -SideButton.WIDTH - 2;
        button.field_146129_i = field_147009_r + lastSideButtonY;

        lastSideButtonY += SideButton.HEIGHT + 2;

        field_146292_n.add(button);

        return button;
    }

    public boolean inBounds(int x, int y, int w, int h, int ox, int oy) {
        return ox >= x && ox <= x + w && oy >= y && oy <= y + h;
    }

    public void bindTexture(String file) {
        bindTexture(RS.ID, file);
    }

    public void bindTexture(String base, String file) {
        String id = base + ":" + file;

        if (!TEXTURE_CACHE.containsKey(id)) {
            TEXTURE_CACHE.put(id, new ResourceLocation(base, "textures/" + file));
        }

        field_146297_k.func_110434_K().func_110577_a(TEXTURE_CACHE.get(id));
    }

    public void drawItem(int x, int y, ItemStack stack) {
        drawItem(x, y, stack, false);
    }

    public void drawItem(int x, int y, ItemStack stack, boolean withOverlay) {
        drawItem(x, y, stack, withOverlay, null);
    }

    public void drawItem(int x, int y, ItemStack stack, boolean withOverlay, @Nullable String text) {
        field_73735_i = 200.0F;
        field_146296_j.field_77023_b = 200.0F;

        try {
            field_146296_j.func_175042_a(stack, x, y);
        } catch (Throwable t) {
            // NO OP
        }

        if (withOverlay) {
            drawItemOverlay(stack, text, x, y);
        }

        field_73735_i = 0.0F;
        field_146296_j.field_77023_b = 0.0F;
    }

    public void drawItemOverlay(ItemStack stack, @Nullable String text, int x, int y) {
        try {
            field_146296_j.func_180453_a(field_146289_q, stack, x, y, "");
        } catch (Throwable t) {
            // NO OP
        }

        if (text != null) {
            drawQuantity(x, y, text);
        }
    }

    public void drawQuantity(int x, int y, String qty) {
        boolean large = field_146289_q.func_82883_a() || RS.INSTANCE.config.largeFont;

        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b(x, y, 1);

        if (!large) {
            GlStateManager.func_179152_a(0.5f, 0.5f, 1);
        }

        GlStateManager.func_179140_f();
        GlStateManager.func_179101_C();
        GlStateManager.func_179132_a(false);
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(770, 771);
        GlStateManager.func_179097_i();

        field_146289_q.func_175063_a(qty, (large ? 16 : 30) - field_146289_q.func_78256_a(qty), large ? 8 : 22, 16777215);

        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179145_e();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    public void drawString(int x, int y, String message) {
        drawString(x, y, message, 4210752);
    }

    public void drawString(int x, int y, String message, int color) {
        GlStateManager.func_179140_f();
        field_146289_q.func_78276_b(message, x, y, color);
        GlStateManager.func_179145_e();
    }

    public void drawTooltip(@Nonnull ItemStack stack, int x, int y, String lines) {
        drawTooltip(stack, x, y, Arrays.asList(lines.split("\n")));
    }

    public void drawTooltip(int x, int y, String lines) {
        drawTooltip(ItemStack.field_190927_a, x, y, lines);
    }

    public void drawTooltip(@Nonnull ItemStack stack, int x, int y, List<String> lines) {
        GlStateManager.func_179140_f();
        GuiUtils.drawHoveringText(stack, lines, x, y, field_146294_l - field_147003_i, field_146295_m, -1, field_146289_q);
        GlStateManager.func_179145_e();
    }

    public void drawTexture(int x, int y, int textureX, int textureY, int width, int height) {
        func_73729_b(x, y, textureX, textureY, width, height);
    }

    public static String t(String name, Object... format) {
        return I18n.func_135052_a(name, format);
    }

    public abstract void init(int x, int y);

    public abstract void update(int x, int y);

    public abstract void drawBackground(int x, int y, int mouseX, int mouseY);

    public abstract void drawForeground(int mouseX, int mouseY);

    public int getGuiLeft() {
        return field_147003_i;
    }

    public int getGuiTop() {
        return field_147009_r;
    }

    public static <T> void executeLater(Class<T> clazz, Consumer<T> callback) {
        Queue<Consumer> queue = RUNNABLES.get(clazz);

        if (queue == null) {
            RUNNABLES.put(clazz, queue = new ArrayDeque<>());
        }

        queue.add(callback);
    }

    public static void executeLater(Consumer<GuiContainer> callback) {
        executeLater(GuiContainer.class, callback);
    }
}
