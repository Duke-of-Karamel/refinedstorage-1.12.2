package com.raoulvdberge.refinedstorage.gui;

import com.google.common.primitives.Ints;
import com.raoulvdberge.refinedstorage.api.util.IComparer;
import com.raoulvdberge.refinedstorage.container.ContainerDetector;
import com.raoulvdberge.refinedstorage.gui.control.SideButtonCompare;
import com.raoulvdberge.refinedstorage.gui.control.SideButtonDetectorMode;
import com.raoulvdberge.refinedstorage.gui.control.SideButtonType;
import com.raoulvdberge.refinedstorage.tile.TileDetector;
import com.raoulvdberge.refinedstorage.tile.data.TileDataManager;
import net.minecraft.client.gui.GuiTextField;

import java.io.IOException;

public class GuiDetector extends GuiBase {
    private GuiTextField amount;

    public GuiDetector(ContainerDetector container) {
        super(container, 176, 137);
    }

    @Override
    public void init(int x, int y) {
        addSideButton(new SideButtonType(this, TileDetector.TYPE));

        addSideButton(new SideButtonDetectorMode(this));

        addSideButton(new SideButtonCompare(this, TileDetector.COMPARE, IComparer.COMPARE_DAMAGE));
        addSideButton(new SideButtonCompare(this, TileDetector.COMPARE, IComparer.COMPARE_NBT));

        amount = new GuiTextField(0, field_146289_q, x + 41 + 1, y + 23 + 1, 50, field_146289_q.field_78288_b);
        amount.func_146180_a(String.valueOf(TileDetector.AMOUNT.getValue()));
        amount.func_146185_a(false);
        amount.func_146189_e(true);
        amount.func_146193_g(16777215);
        amount.func_146205_d(true);
        amount.func_146195_b(false);
    }

    @Override
    public void update(int x, int y) {
    }

    @Override
    public void drawBackground(int x, int y, int mouseX, int mouseY) {
        bindTexture("gui/detector.png");

        drawTexture(x, y, 0, 0, screenWidth, screenHeight);

        amount.func_146194_f();
    }

    @Override
    public void drawForeground(int mouseX, int mouseY) {
        drawString(7, 7, t("gui.refinedstorage:detector"));
        drawString(7, 43, t("container.inventory"));
    }

    @Override
    protected void func_73869_a(char character, int keyCode) throws IOException {
        if (!func_146983_a(keyCode) && amount.func_146201_a(character, keyCode)) {
            Integer result = Ints.tryParse(amount.func_146179_b());

            if (result != null) {
                TileDataManager.setParameter(TileDetector.AMOUNT, result);
            }
        } else {
            super.func_73869_a(character, keyCode);
        }
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);

        amount.func_146192_a(mouseX, mouseY, mouseButton);
    }

    public GuiTextField getAmount() {
        return amount;
    }
}
