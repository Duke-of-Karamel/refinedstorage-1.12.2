package com.raoulvdberge.refinedstorage.gui;

import com.google.common.primitives.Ints;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.inventory.Container;
import net.minecraftforge.fml.client.FMLClientHandler;
import org.apache.commons.lang3.tuple.Pair;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public abstract class GuiAmountSpecifying extends GuiBase {
    protected GuiTextField amountField;

    private GuiBase parent;

    protected GuiButton okButton;
    private GuiButton cancelButton;

    private GuiButton[] incrementButtons = new GuiButton[6];

    public GuiAmountSpecifying(GuiBase parent, Container container, int width, int height) {
        super(container, width, height);

        this.parent = parent;
    }

    protected abstract String getOkButtonText();

    protected abstract String getTitle();

    protected abstract String getTexture();

    protected abstract int[] getIncrements();

    protected abstract int getDefaultAmount();

    protected abstract boolean canAmountGoNegative();

    protected abstract int getMaxAmount();

    protected Pair<Integer, Integer> getAmountPos() {
        return Pair.of(7 + 2, 50 + 1);
    }

    protected Pair<Integer, Integer> getOkCancelPos() {
        return Pair.of(114, 33);
    }

    @Override
    public void init(int x, int y) {
        Pair<Integer, Integer> pos = getOkCancelPos();

        okButton = addButton(x + pos.getLeft(), y + pos.getRight(), 50, 20, getOkButtonText());
        cancelButton = addButton(x + pos.getLeft(), y + pos.getRight() + 24, 50, 20, t("gui.cancel"));

        amountField = new GuiTextField(0, field_146289_q, x + getAmountPos().getLeft(), y + getAmountPos().getRight(), 69 - 6, field_146289_q.field_78288_b);
        amountField.func_146185_a(false);
        amountField.func_146189_e(true);
        amountField.func_146180_a(String.valueOf(getDefaultAmount()));
        amountField.func_146193_g(16777215);
        amountField.func_146205_d(false);
        amountField.func_146195_b(true);

        int[] increments = getIncrements();

        int xx = 7;
        int width = 30;

        for (int i = 0; i < 3; ++i) {
            String text = "+" + increments[i];

            if (text.equals("+1000")) {
                text = "+1B";
            }

            incrementButtons[i] = addButton(x + xx, y + 20, width, 20, text);

            xx += width + 3;
        }

        xx = 7;

        for (int i = 0; i < 3; ++i) {
            String text = "-" + increments[i];

            if (text.equals("-1000")) {
                text = "-1B";
            }

            incrementButtons[3 + i] = addButton(x + xx, y + screenHeight - 20 - 7, width, 20, text);

            xx += width + 3;
        }
    }

    @Override
    public void update(int x, int y) {
        // NO OP
    }

    @Override
    public void drawBackground(int x, int y, int mouseX, int mouseY) {
        bindTexture(getTexture());

        drawTexture(x, y, 0, 0, screenWidth, screenHeight);

        amountField.func_146194_f();
    }

    @Override
    public void drawForeground(int mouseX, int mouseY) {
        drawString(7, 7, getTitle());
    }

    @Override
    protected void func_73869_a(char character, int keyCode) throws IOException {
        if (!func_146983_a(keyCode) && amountField.func_146201_a(character, keyCode)) {
            // NO OP
        } else {
            if (keyCode == Keyboard.KEY_RETURN) {
                onOkButtonPressed(func_146272_n());
            } else if (keyCode == Keyboard.KEY_ESCAPE) {
                close();
            } else {
                super.func_73869_a(character, keyCode);
            }
        }
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        super.func_146284_a(button);

        if (button.field_146127_k == okButton.field_146127_k) {
            onOkButtonPressed(func_146272_n());
        } else if (button.field_146127_k == cancelButton.field_146127_k) {
            close();
        } else {
            for (GuiButton incrementButton : incrementButtons) {
                if (incrementButton.field_146127_k == button.field_146127_k) {
                    Integer oldAmount = Ints.tryParse(amountField.func_146179_b());

                    if (oldAmount == null) {
                        oldAmount = 0;
                    }

                    String incrementButtonText = incrementButton.field_146126_j;

                    if (incrementButtonText.equals("+1B")) {
                        incrementButtonText = "1000";
                    } else if (incrementButtonText.equals("-1B")) {
                        incrementButtonText = "-1000";
                    }

                    int newAmount = Integer.parseInt(incrementButtonText);

                    if (!canAmountGoNegative()) {
                        newAmount = Math.max(1, ((oldAmount == 1 && newAmount != 1) ? 0 : oldAmount) + newAmount);
                    } else {
                        newAmount = oldAmount + newAmount;
                    }

                    if (newAmount > getMaxAmount()) {
                        newAmount = getMaxAmount();
                    }

                    amountField.func_146180_a(String.valueOf(newAmount));

                    break;
                }
            }
        }
    }

    protected void onOkButtonPressed(boolean shiftDown) {
        // NO OP
    }

    public void close() {
        FMLClientHandler.instance().showGuiScreen(parent);
    }

    public GuiBase getParent() {
        return parent;
    }
}
