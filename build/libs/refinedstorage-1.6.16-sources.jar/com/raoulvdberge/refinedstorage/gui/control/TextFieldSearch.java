package com.raoulvdberge.refinedstorage.gui.control;

import com.raoulvdberge.refinedstorage.RSKeyBindings;
import com.raoulvdberge.refinedstorage.api.network.grid.IGrid;
import com.raoulvdberge.refinedstorage.integration.jei.IntegrationJEI;
import com.raoulvdberge.refinedstorage.integration.jei.RSJEIPlugin;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiTextField;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class TextFieldSearch extends GuiTextField {
    private static final List<String> HISTORY = new ArrayList<>();

    private int mode;
    private int historyIndex = -1;

    private List<Runnable> listeners = new LinkedList<>();

    public TextFieldSearch(int componentId, FontRenderer fontRenderer, int x, int y, int width) {
        super(componentId, fontRenderer, x, y, width, fontRenderer.field_78288_b);

        this.func_146185_a(false);
        this.func_146189_e(true);
        this.func_146193_g(16777215);

        this.listeners.add(() -> {
            if (IntegrationJEI.isLoaded() && (mode == IGrid.SEARCH_BOX_MODE_JEI_SYNCHRONIZED || mode == IGrid.SEARCH_BOX_MODE_JEI_SYNCHRONIZED_AUTOSELECTED)) {
                RSJEIPlugin.INSTANCE.getRuntime().getIngredientFilter().setFilterText(func_146179_b());
            }
        });
    }

    public void addListener(Runnable listener) {
        listeners.add(listener);
    }

    @Override
    public boolean func_146192_a(int mouseX, int mouseY, int mouseButton) {
        boolean wasFocused = func_146206_l();

        boolean result = super.func_146192_a(mouseX, mouseY, mouseButton);

        boolean flag = mouseX >= this.field_146209_f && mouseX < this.field_146209_f + this.field_146218_h && mouseY >= this.field_146210_g && mouseY < this.field_146210_g + this.field_146219_i;

        if (flag && mouseButton == 1) {
            func_146180_a("");
            func_146195_b(true);

            listeners.forEach(Runnable::run);
        } else if (wasFocused != func_146206_l()) {
            saveHistory();
        }

        return result;
    }

    @Override
    public boolean func_146201_a(char typedChar, int keyCode) {
        @SuppressWarnings("deprecation") boolean canLoseFocus = ObfuscationReflectionHelper.getPrivateValue(GuiTextField.class, this, 10);

        boolean result = super.func_146201_a(typedChar, keyCode);

        if (func_146206_l()) {
            if (keyCode == Keyboard.KEY_UP) {
                updateSearchHistory(-1);

                result = true;
            } else if (keyCode == Keyboard.KEY_DOWN) {
                updateSearchHistory(1);

                result = true;
            } else if (keyCode == Keyboard.KEY_RETURN) {
                saveHistory();

                if (canLoseFocus) {
                    func_146195_b(false);
                }

                result = true;
            }
        }

        if (keyCode == RSKeyBindings.FOCUS_SEARCH_BAR.func_151463_i() && canLoseFocus) {
            func_146195_b(!func_146206_l());

            saveHistory();

            result = true;
        }

        if (result) {
            listeners.forEach(Runnable::run);
        }

        return result;
    }

    private void updateSearchHistory(int delta) {
        if (HISTORY.isEmpty()) {
            return;
        }

        if (historyIndex == -1) {
            historyIndex = HISTORY.size();
        }

        historyIndex += delta;

        if (historyIndex < 0) {
            historyIndex = 0;
        } else if (historyIndex > HISTORY.size() - 1) {
            historyIndex = HISTORY.size() - 1;

            if (delta == 1) {
                func_146180_a("");

                listeners.forEach(Runnable::run);

                return;
            }
        }

        func_146180_a(HISTORY.get(historyIndex));

        listeners.forEach(Runnable::run);
    }

    private void saveHistory() {
        if (!HISTORY.isEmpty() && HISTORY.get(HISTORY.size() - 1).equals(func_146179_b())) {
            return;
        }

        if (!func_146179_b().trim().isEmpty()) {
            HISTORY.add(func_146179_b());
        }
    }

    public void setMode(int mode) {
        this.mode = mode;

        this.func_146205_d(!IGrid.isSearchBoxModeWithAutoselection(mode));
        this.func_146195_b(IGrid.isSearchBoxModeWithAutoselection(mode));
    }
}
