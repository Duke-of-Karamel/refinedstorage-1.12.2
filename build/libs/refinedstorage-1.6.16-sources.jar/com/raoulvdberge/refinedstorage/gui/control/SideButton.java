package com.raoulvdberge.refinedstorage.gui.control;

import com.raoulvdberge.refinedstorage.gui.GuiBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

public abstract class SideButton extends GuiButton {
    public static final int WIDTH = 18;
    public static final int HEIGHT = 18;

    protected GuiBase gui;

    public SideButton(GuiBase gui) {
        super(-1, -1, -1, 18, 18, "");

        this.gui = gui;
    }

    public boolean isHovered() {
        return field_146123_n;
    }

    @Override
    public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.func_179141_d();

        field_146123_n = gui.inBounds(field_146128_h, field_146129_i, field_146120_f, field_146121_g, mouseX, mouseY);

        gui.bindTexture("icons.png");
        gui.drawTexture(field_146128_h, field_146129_i, 238, field_146123_n ? 35 : 16, 18, 18);

        drawButtonIcon(field_146128_h + 1, field_146129_i + 1);

        if (field_146123_n) {
            GlStateManager.func_179147_l();
            GlStateManager.func_179112_b(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 0.5f);
            gui.drawTexture(field_146128_h, field_146129_i, 238, 54, 18, 18);
            GlStateManager.func_179084_k();
        }
    }

    protected abstract void drawButtonIcon(int x, int y);

    public abstract String getTooltip();

    public abstract void actionPerformed();
}
