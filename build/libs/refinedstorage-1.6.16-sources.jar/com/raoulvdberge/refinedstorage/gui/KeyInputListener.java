package com.raoulvdberge.refinedstorage.gui;

import com.raoulvdberge.refinedstorage.RS;
import com.raoulvdberge.refinedstorage.RSBlocks;
import com.raoulvdberge.refinedstorage.RSItems;
import com.raoulvdberge.refinedstorage.RSKeyBindings;
import com.raoulvdberge.refinedstorage.network.MessageNetworkItemOpen;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;

public class KeyInputListener {
    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent e) {
        InventoryPlayer inv = Minecraft.func_71410_x().field_71439_g.field_71071_by;

        if (RSKeyBindings.OPEN_WIRELESS_GRID.func_151470_d()) {
            findAndOpen(inv, RSItems.WIRELESS_GRID);
        } else if (RSKeyBindings.OPEN_WIRELESS_FLUID_GRID.func_151470_d()) {
            findAndOpen(inv, RSItems.WIRELESS_FLUID_GRID);
        } else if (RSKeyBindings.OPEN_PORTABLE_GRID.func_151470_d()) {
            findAndOpen(inv, Item.func_150898_a(RSBlocks.PORTABLE_GRID));
        } else if (RSKeyBindings.OPEN_WIRELESS_CRAFTING_MONITOR.func_151470_d()) {
            findAndOpen(inv, RSItems.WIRELESS_CRAFTING_MONITOR);
        }
    }

    private void findAndOpen(IInventory inv, Item search) {
        for (int i = 0; i < inv.func_70302_i_(); ++i) {
            ItemStack slot = inv.func_70301_a(i);

            if (slot.func_77973_b() == search) {
                RS.INSTANCE.network.sendToServer(new MessageNetworkItemOpen(i));

                return;
            }
        }
    }
}
