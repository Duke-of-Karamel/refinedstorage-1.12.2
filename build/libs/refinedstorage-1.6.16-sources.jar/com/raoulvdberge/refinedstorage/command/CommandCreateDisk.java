package com.raoulvdberge.refinedstorage.command;

import com.raoulvdberge.refinedstorage.api.storage.disk.IStorageDisk;
import com.raoulvdberge.refinedstorage.api.storage.disk.IStorageDiskProvider;
import com.raoulvdberge.refinedstorage.apiimpl.API;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class CommandCreateDisk extends CommandBase {
    @Override
    public String func_71517_b() {
        return "createdisk";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "commands.refinedstorage.createdisk.usage";
    }

    @Override
    public int func_82362_a() {
        return 2;
    }

    @Override
    public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length < 4) {
            throw new WrongUsageException("commands.refinedstorage.createdisk.usage");
        } else {
            EntityPlayer player = func_184888_a(server, sender, args[0]);
            Item item = func_147179_f(sender, args[1]);
            int metadata = func_175755_a(args[2]);

            UUID id;
            try {
                id = UUID.fromString(args[3]);
            } catch (IllegalArgumentException e) {
                throw new CommandException("commands.refinedstorage.createdisk.error.diskNotFound", args[3]);
            }

            if (!(item instanceof IStorageDiskProvider)) {
                throw new CommandException("commands.refinedstorage.createdisk.error.notADisk");
            }

            IStorageDisk disk = API.instance().getStorageDiskManager(sender.func_130014_f_()).get(id);
            if (disk == null) {
                throw new CommandException("commands.refinedstorage.createdisk.error.diskNotFound", args[3]);
            }

            ItemStack diskStack = new ItemStack(item, 1, metadata);
            ((IStorageDiskProvider) item).setId(diskStack, id);

            if (player.field_71071_by.func_70441_a(diskStack)) {
                // From CommandGive
                player.field_70170_p.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187638_cR, SoundCategory.PLAYERS, 0.2F, ((player.func_70681_au().nextFloat() - player.func_70681_au().nextFloat()) * 0.7F + 1.0F) * 2.0F);
                player.field_71069_bz.func_75142_b();
            }

            func_152373_a(sender, this, "commands.refinedstorage.createdisk.success", args[3], player.func_70005_c_());
        }
    }

    @Override
    public List<String> func_184883_a(MinecraftServer server, ICommandSender sender, String[] args, @Nullable BlockPos targetPos) {
        if (args.length == 1) {
            return func_71530_a(args, server.func_71213_z());
        } else if (args.length == 2) {
            return func_175762_a(args, Item.field_150901_e.func_148742_b());
        } else if (args.length == 4) {
            return func_175762_a(args, API.instance().getStorageDiskManager(sender.func_130014_f_()).getAll().keySet().stream().map(UUID::toString).collect(Collectors.toList()));
        }

        return Collections.emptyList();
    }
}
