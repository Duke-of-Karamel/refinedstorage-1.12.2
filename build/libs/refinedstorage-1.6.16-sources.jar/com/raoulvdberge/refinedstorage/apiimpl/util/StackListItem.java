package com.raoulvdberge.refinedstorage.apiimpl.util;

import com.google.common.collect.ArrayListMultimap;
import com.raoulvdberge.refinedstorage.api.util.IStackList;
import com.raoulvdberge.refinedstorage.apiimpl.API;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collection;

public class StackListItem implements IStackList<ItemStack> {
    private ArrayListMultimap<Item, ItemStack> stacks = ArrayListMultimap.create();

    @Override
    public void add(@Nonnull ItemStack stack, int size) {
        if (stack.func_190926_b() || size <= 0) {
            throw new IllegalArgumentException("Cannot accept empty stack");
        }

        for (ItemStack otherStack : stacks.get(stack.func_77973_b())) {
            if (API.instance().getComparer().isEqualNoQuantity(otherStack, stack)) {
                if ((long) otherStack.func_190916_E() + (long) size > Integer.MAX_VALUE) {
                    otherStack.func_190920_e(Integer.MAX_VALUE);
                } else {
                    otherStack.func_190917_f(size);
                }

                return;
            }
        }

        stacks.put(stack.func_77973_b(), ItemHandlerHelper.copyStackWithSize(stack, size));
    }

    @Override
    public void add(@Nonnull ItemStack stack) {
        add(stack, stack.func_190916_E());
    }

    @Override
    public boolean remove(@Nonnull ItemStack stack, int size) {
        for (ItemStack otherStack : stacks.get(stack.func_77973_b())) {
            if (API.instance().getComparer().isEqualNoQuantity(otherStack, stack)) {
                boolean success = otherStack.func_190916_E() - size >= 0;

                if (otherStack.func_190916_E() - size <= 0) {
                    stacks.remove(otherStack.func_77973_b(), otherStack);
                } else {
                    otherStack.func_190918_g(size);
                }

                return success;
            }
        }

        return false;
    }

    @Override
    public boolean remove(@Nonnull ItemStack stack) {
        return remove(stack, stack.func_190916_E());
    }

    @Override
    @Nullable
    public ItemStack get(@Nonnull ItemStack stack, int flags) {
        for (ItemStack otherStack : stacks.get(stack.func_77973_b())) {
            if (API.instance().getComparer().isEqual(otherStack, stack, flags)) {
                return otherStack;
            }
        }

        return null;
    }

    @Override
    @Nullable
    public ItemStack get(int hash) {
        for (ItemStack stack : this.stacks.values()) {
            if (API.instance().getItemStackHashCode(stack) == hash) {
                return stack;
            }
        }

        return null;
    }

    @Override
    public void clear() {
        stacks.clear();
    }

    @Override
    public boolean isEmpty() {
        return stacks.isEmpty();
    }

    @Nonnull
    @Override
    public Collection<ItemStack> getStacks() {
        return stacks.values();
    }

    @Override
    @Nonnull
    public IStackList<ItemStack> copy() {
        StackListItem list = new StackListItem();

        for (ItemStack stack : stacks.values()) {
            list.stacks.put(stack.func_77973_b(), stack.func_77946_l());
        }

        return list;
    }
}
