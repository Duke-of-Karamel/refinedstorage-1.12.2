package com.raoulvdberge.refinedstorage.apiimpl.network.item;

import com.raoulvdberge.refinedstorage.api.network.INetwork;
import com.raoulvdberge.refinedstorage.api.network.IWirelessTransmitter;
import com.raoulvdberge.refinedstorage.api.network.item.INetworkItem;
import com.raoulvdberge.refinedstorage.api.network.item.INetworkItemHandler;
import com.raoulvdberge.refinedstorage.api.network.item.INetworkItemProvider;
import com.raoulvdberge.refinedstorage.api.network.node.INetworkNode;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentTranslation;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NetworkItemHandler implements INetworkItemHandler {
    private INetwork network;

    private Map<EntityPlayer, INetworkItem> items = new ConcurrentHashMap<>();

    public NetworkItemHandler(INetwork network) {
        this.network = network;
    }

    @Override
    public void open(EntityPlayer player, ItemStack stack, int slotId) {
        boolean inRange = false;

        for (INetworkNode node : network.getNodeGraph().all()) {
            if (node instanceof IWirelessTransmitter && node.canUpdate() && ((IWirelessTransmitter) node).getDimension() == player.field_71093_bK) {
                IWirelessTransmitter transmitter = (IWirelessTransmitter) node;

                double distance = Math.sqrt(Math.pow(transmitter.getOrigin().func_177958_n() - player.field_70165_t, 2) + Math.pow(transmitter.getOrigin().func_177956_o() - player.field_70163_u, 2) + Math.pow(transmitter.getOrigin().func_177952_p() - player.field_70161_v, 2));

                if (distance < transmitter.getRange()) {
                    inRange = true;

                    break;
                }
            }
        }

        if (!inRange) {
            player.func_145747_a(new TextComponentTranslation("misc.refinedstorage:network_item.out_of_range"));

            return;
        }

        INetworkItem item = ((INetworkItemProvider) stack.func_77973_b()).provide(this, player, stack, slotId);

        if (item.onOpen(network)) {
            items.put(player, item);
        }
    }

    @Override
    public void close(EntityPlayer player) {
        items.remove(player);
    }

    @Override
    public INetworkItem getItem(EntityPlayer player) {
        return items.get(player);
    }

    @Override
    public void drainEnergy(EntityPlayer player, int energy) {
        INetworkItem item = getItem(player);

        if (item != null) {
            item.drainEnergy(energy);
        }
    }
}
