package com.raoulvdberge.refinedstorage.apiimpl.network.node;

import com.raoulvdberge.refinedstorage.RS;
import com.raoulvdberge.refinedstorage.RSBlocks;
import com.raoulvdberge.refinedstorage.RSItems;
import com.raoulvdberge.refinedstorage.api.network.INetwork;
import com.raoulvdberge.refinedstorage.api.network.grid.*;
import com.raoulvdberge.refinedstorage.api.network.grid.handler.IFluidGridHandler;
import com.raoulvdberge.refinedstorage.api.network.grid.handler.IItemGridHandler;
import com.raoulvdberge.refinedstorage.api.network.security.Permission;
import com.raoulvdberge.refinedstorage.api.storage.IStorageCache;
import com.raoulvdberge.refinedstorage.api.storage.IStorageCacheListener;
import com.raoulvdberge.refinedstorage.api.util.Action;
import com.raoulvdberge.refinedstorage.api.util.IComparer;
import com.raoulvdberge.refinedstorage.api.util.IFilter;
import com.raoulvdberge.refinedstorage.apiimpl.API;
import com.raoulvdberge.refinedstorage.apiimpl.storage.StorageCacheListenerGridFluid;
import com.raoulvdberge.refinedstorage.apiimpl.storage.StorageCacheListenerGridItem;
import com.raoulvdberge.refinedstorage.block.BlockGrid;
import com.raoulvdberge.refinedstorage.inventory.fluid.FluidInventory;
import com.raoulvdberge.refinedstorage.inventory.item.ItemHandlerBase;
import com.raoulvdberge.refinedstorage.inventory.item.ItemHandlerFilter;
import com.raoulvdberge.refinedstorage.inventory.item.validator.ItemValidatorBasic;
import com.raoulvdberge.refinedstorage.inventory.listener.ListenerNetworkNode;
import com.raoulvdberge.refinedstorage.item.ItemPattern;
import com.raoulvdberge.refinedstorage.tile.config.IType;
import com.raoulvdberge.refinedstorage.tile.data.TileDataManager;
import com.raoulvdberge.refinedstorage.tile.grid.TileGrid;
import com.raoulvdberge.refinedstorage.util.StackUtils;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.*;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.wrapper.CombinedInvWrapper;
import net.minecraftforge.items.wrapper.InvWrapper;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NetworkNodeGrid extends NetworkNode implements IGridNetworkAware, IType {
    public static final String ID = "grid";
    public static int FACTORY_ID = 0;

    public static final String NBT_VIEW_TYPE = "ViewType";
    public static final String NBT_SORTING_DIRECTION = "SortingDirection";
    public static final String NBT_SORTING_TYPE = "SortingType";
    public static final String NBT_SEARCH_BOX_MODE = "SearchBoxMode";
    private static final String NBT_OREDICT_PATTERN = "OredictPattern";
    public static final String NBT_TAB_SELECTED = "TabSelected";
    public static final String NBT_TAB_PAGE = "TabPage";
    public static final String NBT_SIZE = "Size";
    private static final String NBT_PROCESSING_PATTERN = "ProcessingPattern";
    private static final String NBT_PROCESSING_TYPE = "ProcessingType";
    private static final String NBT_PROCESSING_MATRIX_FLUIDS = "ProcessingMatrixFluids";

    private Container craftingContainer = new Container() {
        @Override
        public boolean func_75145_c(EntityPlayer player) {
            return false;
        }

        @Override
        public void func_75130_a(IInventory inventory) {
            if (!world.field_72995_K) {
                onCraftingMatrixChanged();
            }
        }
    };
    private IRecipe currentRecipe;
    private InventoryCrafting matrix = new InventoryCrafting(craftingContainer, 3, 3);
    private InventoryCraftResult result = new InventoryCraftResult();
    private ItemHandlerBase processingMatrix = new ItemHandlerBase(9 * 2, new ListenerNetworkNode(this));
    private FluidInventory processingMatrixFluids = new FluidInventory(9 * 2, Fluid.BUCKET_VOLUME * 64, new ListenerNetworkNode(this));

    private Set<IGridCraftingListener> craftingListeners = new HashSet<>();

    private ItemHandlerBase patterns = new ItemHandlerBase(2, new ListenerNetworkNode(this), new ItemValidatorBasic(RSItems.PATTERN)) {
        @Override
        protected void onContentsChanged(int slot) {
            super.onContentsChanged(slot);

            ItemStack pattern = getStackInSlot(slot);
            if (slot == 1 && !pattern.func_190926_b()) {
                boolean isPatternProcessing = ItemPattern.isProcessing(pattern);

                if (isPatternProcessing && isProcessingPattern()) {
                    for (int i = 0; i < 9; ++i) {
                        processingMatrix.setStackInSlot(i, StackUtils.nullToEmpty(ItemPattern.getInputSlot(pattern, i)));
                        processingMatrixFluids.setFluid(i, ItemPattern.getFluidInputSlot(pattern, i));
                    }

                    for (int i = 0; i < 9; ++i) {
                        processingMatrix.setStackInSlot(9 + i, StackUtils.nullToEmpty(ItemPattern.getOutputSlot(pattern, i)));
                        processingMatrixFluids.setFluid(9 + i, ItemPattern.getFluidOutputSlot(pattern, i));
                    }
                } else if (!isPatternProcessing && !isProcessingPattern()) {
                    for (int i = 0; i < 9; ++i) {
                        matrix.func_70299_a(i, StackUtils.nullToEmpty(ItemPattern.getInputSlot(pattern, i)));
                    }
                }
            }
        }

        @Override
        public int getSlotLimit(int slot) {
            return slot == 1 ? 1 : super.getSlotLimit(slot);
        }

        @Nonnull
        @Override
        public ItemStack insertItem(int slot, @Nonnull ItemStack stack, boolean simulate) {
            // Allow in slot 0
            // Disallow in slot 1
            // Only allow in slot 1 when it isn't a blank pattern
            // This makes it so that written patterns can be re-inserted in slot 1 to be overwritten again
            // This makes it so that blank patterns can't be inserted in slot 1 through hoppers.
            if (slot == 0 || stack.func_77978_p() != null) {
                return super.insertItem(slot, stack, simulate);
            }

            return stack;
        }
    };
    private List<IFilter> filters = new ArrayList<>();
    private List<IGridTab> tabs = new ArrayList<>();
    private ItemHandlerFilter filter = new ItemHandlerFilter(filters, tabs, new ListenerNetworkNode(this));

    private GridType type;

    private int viewType = VIEW_TYPE_NORMAL;
    private int sortingDirection = SORTING_DIRECTION_DESCENDING;
    private int sortingType = SORTING_TYPE_QUANTITY;
    private int searchBoxMode = SEARCH_BOX_MODE_NORMAL;
    private int size = SIZE_STRETCH;

    private int tabSelected = -1;
    private int tabPage = 0;

    private boolean oredictPattern = false;
    private boolean processingPattern = false;
    private int processingType = IType.ITEMS;

    public NetworkNodeGrid(World world, BlockPos pos) {
        super(world, pos);
    }

    @Override
    public int getEnergyUsage() {
        switch (getGridType()) {
            case NORMAL:
                return RS.INSTANCE.config.gridUsage;
            case CRAFTING:
                return RS.INSTANCE.config.craftingGridUsage;
            case PATTERN:
                return RS.INSTANCE.config.patternGridUsage;
            case FLUID:
                return RS.INSTANCE.config.fluidGridUsage;
            default:
                return 0;
        }
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }

    public void setSortingDirection(int sortingDirection) {
        this.sortingDirection = sortingDirection;
    }

    public void setSortingType(int sortingType) {
        this.sortingType = sortingType;
    }

    public void setSearchBoxMode(int searchBoxMode) {
        this.searchBoxMode = searchBoxMode;
    }

    public void setTabSelected(int tabSelected) {
        this.tabSelected = tabSelected;
    }

    public void setTabPage(int page) {
        this.tabPage = page;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public boolean isOredictPattern() {
        return oredictPattern;
    }

    public void setOredictPattern(boolean oredictPattern) {
        this.oredictPattern = oredictPattern;
    }

    public boolean isProcessingPattern() {
        return world.field_72995_K ? TileGrid.PROCESSING_PATTERN.getValue() : processingPattern;
    }

    public void setProcessingPattern(boolean processingPattern) {
        this.processingPattern = processingPattern;
    }

    @Override
    public GridType getGridType() {
        if (type == null) {
            IBlockState state = world.func_180495_p(pos);
            if (state.func_177230_c() == RSBlocks.GRID) {
                type = (GridType) state.func_177229_b(BlockGrid.TYPE);
            }
        }

        return type == null ? GridType.NORMAL : type;
    }

    @Override
    public IStorageCacheListener createListener(EntityPlayerMP player) {
        return getGridType() == GridType.FLUID ? new StorageCacheListenerGridFluid(player, network) : new StorageCacheListenerGridItem(player, network);
    }

    @Nullable
    @Override
    public IStorageCache getStorageCache() {
        return network != null ? (getGridType() == GridType.FLUID ? network.getFluidStorageCache() : network.getItemStorageCache()) : null;
    }

    @Nullable
    @Override
    public IItemGridHandler getItemHandler() {
        return network != null ? network.getItemGridHandler() : null;
    }

    @Nullable
    @Override
    public IFluidGridHandler getFluidHandler() {
        return network != null ? network.getFluidGridHandler() : null;
    }

    @Override
    public void addCraftingListener(IGridCraftingListener listener) {
        craftingListeners.add(listener);
    }

    @Override
    public void removeCraftingListener(IGridCraftingListener listener) {
        craftingListeners.remove(listener);
    }

    @Override
    public String getGuiTitle() {
        GridType type = getGridType();

        switch (type) {
            case CRAFTING:
                return "gui.refinedstorage:crafting_grid";
            case PATTERN:
                return "gui.refinedstorage:pattern_grid";
            case FLUID:
                return "gui.refinedstorage:fluid_grid";
            default:
                return "gui.refinedstorage:grid";
        }
    }

    public IItemHandler getPatterns() {
        return patterns;
    }

    @Override
    public IItemHandlerModifiable getFilter() {
        return filter;
    }

    @Override
    public List<IFilter> getFilters() {
        return filters;
    }

    @Override
    public List<IGridTab> getTabs() {
        return tabs;
    }

    @Override
    public InventoryCrafting getCraftingMatrix() {
        return matrix;
    }

    @Override
    public InventoryCraftResult getCraftingResult() {
        return result;
    }

    public ItemHandlerBase getProcessingMatrix() {
        return processingMatrix;
    }

    public FluidInventory getProcessingMatrixFluids() {
        return processingMatrixFluids;
    }

    @Override
    public void onCraftingMatrixChanged() {
        if (currentRecipe == null || !currentRecipe.func_77569_a(matrix, world)) {
            currentRecipe = CraftingManager.func_192413_b(matrix, world);
        }

        if (currentRecipe == null) {
            result.func_70299_a(0, ItemStack.field_190927_a);
        } else {
            result.func_70299_a(0, currentRecipe.func_77572_b(matrix));
        }

        craftingListeners.forEach(IGridCraftingListener::onCraftingMatrixChanged);

        markDirty();
    }

    @Override
    public void onRecipeTransfer(EntityPlayer player, ItemStack[][] recipe) {
        onRecipeTransfer(this, player, recipe);
    }

    public static void onRecipeTransfer(IGridNetworkAware grid, EntityPlayer player, ItemStack[][] recipe) {
        INetwork network = grid.getNetwork();

        if (network != null && grid.getGridType() == GridType.CRAFTING && !network.getSecurityManager().hasPermission(Permission.EXTRACT, player)) {
            return;
        }

        // First try to empty the crafting matrix
        for (int i = 0; i < grid.getCraftingMatrix().func_70302_i_(); ++i) {
            ItemStack slot = grid.getCraftingMatrix().func_70301_a(i);

            if (!slot.func_190926_b()) {
                // Only if we are a crafting grid. Pattern grids can just be emptied.
                if (grid.getGridType() == GridType.CRAFTING) {
                    // If we are connected, try to insert into network. If it fails, stop.
                    if (network != null) {
                        if (network.insertItem(slot, slot.func_190916_E(), Action.SIMULATE) != null) {
                            return;
                        } else {
                            network.insertItem(slot, slot.func_190916_E(), Action.PERFORM);

                            network.getItemStorageTracker().changed(player, slot.func_77946_l());
                        }
                    } else {
                        // If we aren't connected, try to insert into player inventory. If it fails, stop.
                        if (!player.field_71071_by.func_70441_a(slot.func_77946_l())) {
                            return;
                        }
                    }
                }

                grid.getCraftingMatrix().func_70299_a(i, ItemStack.field_190927_a);
            }
        }

        // Now let's fill the matrix
        for (int i = 0; i < grid.getCraftingMatrix().func_70302_i_(); ++i) {
            if (recipe[i] != null) {
                ItemStack[] possibilities = recipe[i];

                // If we are a crafting grid
                if (grid.getGridType() == GridType.CRAFTING) {
                    boolean found = false;

                    // If we are connected, first try to get the possibilities from the network
                    if (network != null) {
                        for (ItemStack possibility : possibilities) {
                            ItemStack took = network.extractItem(possibility, 1, IComparer.COMPARE_NBT | (possibility.func_77973_b().func_77645_m() ? 0 : IComparer.COMPARE_DAMAGE), Action.PERFORM);

                            if (took != null) {
                                grid.getCraftingMatrix().func_70299_a(i, StackUtils.nullToEmpty(took));

                                network.getItemStorageTracker().changed(player, took.func_77946_l());

                                found = true;

                                break;
                            }
                        }
                    }

                    // If we haven't found anything in the network (or we are disconnected), go look in the player inventory
                    if (!found) {
                        for (ItemStack possibility : possibilities) {
                            for (int j = 0; j < player.field_71071_by.func_70302_i_(); ++j) {
                                if (API.instance().getComparer().isEqual(possibility, player.field_71071_by.func_70301_a(j), IComparer.COMPARE_NBT | (possibility.func_77973_b().func_77645_m() ? 0 : IComparer.COMPARE_DAMAGE))) {
                                    grid.getCraftingMatrix().func_70299_a(i, ItemHandlerHelper.copyStackWithSize(player.field_71071_by.func_70301_a(j), 1));

                                    player.field_71071_by.func_70298_a(j, 1);

                                    found = true;

                                    break;
                                }
                            }

                            if (found) {
                                break;
                            }
                        }
                    }
                } else if (grid.getGridType() == GridType.PATTERN) {
                    // If we are a pattern grid we can just set the slot
                    grid.getCraftingMatrix().func_70299_a(i, possibilities.length == 0 ? ItemStack.field_190927_a : possibilities[0]);
                }
            }
        }
    }

    public void clearMatrix() {
        for (int i = 0; i < processingMatrix.getSlots(); ++i) {
            processingMatrix.setStackInSlot(i, ItemStack.field_190927_a);
        }

        for (int i = 0; i < processingMatrixFluids.getSlots(); ++i) {
            processingMatrixFluids.setFluid(i, null);
        }

        for (int i = 0; i < matrix.func_70302_i_(); ++i) {
            matrix.func_70299_a(i, ItemStack.field_190927_a);
        }
    }

    @Override
    public void onClosed(EntityPlayer player) {
        // NO OP
    }

    @Override
    public int getSlotId() {
        return -1;
    }

    @Override
    public void onCrafted(EntityPlayer player) {
        onCrafted(this, world, player);
    }

    public static void onCrafted(IGridNetworkAware grid, World world, EntityPlayer player) {
        NonNullList<ItemStack> remainder = CraftingManager.func_180303_b(grid.getCraftingMatrix(), world);

        INetwork network = grid.getNetwork();

        InventoryCrafting matrix = grid.getCraftingMatrix();

        for (int i = 0; i < grid.getCraftingMatrix().func_70302_i_(); ++i) {
            ItemStack slot = matrix.func_70301_a(i);

            if (i < remainder.size() && !remainder.get(i).func_190926_b()) {
                // If there is no space for the remainder, dump it in the player inventory
                if (!slot.func_190926_b() && slot.func_190916_E() > 1) {
                    if (!player.field_71071_by.func_70441_a(remainder.get(i).func_77946_l())) {
                        ItemStack remainderStack = network == null ? remainder.get(i).func_77946_l() : network.insertItem(remainder.get(i).func_77946_l(), remainder.get(i).func_190916_E(), Action.PERFORM);

                        if (remainderStack != null) {
                            InventoryHelper.func_180173_a(player.func_130014_f_(), player.func_180425_c().func_177958_n(), player.func_180425_c().func_177956_o(), player.func_180425_c().func_177952_p(), remainderStack);
                        }
                    }

                    matrix.func_70298_a(i, 1);
                } else {
                    matrix.func_70299_a(i, remainder.get(i).func_77946_l());
                }
            } else if (!slot.func_190926_b()) {
                if (slot.func_190916_E() == 1 && network != null) {
                    ItemStack refill = StackUtils.nullToEmpty(network.extractItem(slot, 1, Action.PERFORM));

                    matrix.func_70299_a(i, refill);

                    if (!refill.func_190926_b()) {
                        network.getItemStorageTracker().changed(player, refill.func_77946_l());
                    }
                } else {
                    matrix.func_70298_a(i, 1);
                }
            }
        }

        grid.onCraftingMatrixChanged();
    }

    @Override
    public void onCraftedShift(EntityPlayer player) {
        onCraftedShift(this, player);
    }

    public static void onCraftedShift(IGridNetworkAware grid, EntityPlayer player) {
        List<ItemStack> craftedItemsList = new ArrayList<>();
        int craftedItems = 0;
        ItemStack crafted = grid.getCraftingResult().func_70301_a(0);

        while (true) {
            grid.onCrafted(player);

            craftedItemsList.add(crafted.func_77946_l());

            craftedItems += crafted.func_190916_E();

            if (!API.instance().getComparer().isEqual(crafted, grid.getCraftingResult().func_70301_a(0)) || craftedItems + crafted.func_190916_E() > crafted.func_77976_d()) {
                break;
            }
        }

        INetwork network = grid.getNetwork();

        for (ItemStack craftedItem : craftedItemsList) {
            if (!player.field_71071_by.func_70441_a(craftedItem.func_77946_l())) {
                ItemStack remainder = network == null ? craftedItem : network.insertItem(craftedItem, craftedItem.func_190916_E(), Action.PERFORM);

                if (remainder != null) {
                    InventoryHelper.func_180173_a(player.func_130014_f_(), player.func_180425_c().func_177958_n(), player.func_180425_c().func_177956_o(), player.func_180425_c().func_177952_p(), remainder);
                }
            }
        }

        FMLCommonHandler.instance().firePlayerCraftingEvent(player, ItemHandlerHelper.copyStackWithSize(crafted, craftedItems), grid.getCraftingMatrix());
    }

    public void onCreatePattern() {
        if (canCreatePattern()) {
            if (patterns.getStackInSlot(1).func_190926_b()) {
                patterns.extractItem(0, 1, false);
            }

            ItemStack pattern = new ItemStack(RSItems.PATTERN);

            ItemPattern.setVersion(pattern);
            ItemPattern.setOredict(pattern, oredictPattern);
            ItemPattern.setProcessing(pattern, processingPattern);

            if (processingPattern) {
                for (int i = 0; i < 18; ++i) {
                    if (!processingMatrix.getStackInSlot(i).func_190926_b()) {
                        if (i >= 9) {
                            ItemPattern.setOutputSlot(pattern, i - 9, processingMatrix.getStackInSlot(i));
                        } else {
                            ItemPattern.setInputSlot(pattern, i, processingMatrix.getStackInSlot(i));
                        }
                    }

                    FluidStack fluid = processingMatrixFluids.getFluid(i);
                    if (fluid != null) {
                        if (i >= 9) {
                            ItemPattern.setFluidOutputSlot(pattern, i - 9, fluid);
                        } else {
                            ItemPattern.setFluidInputSlot(pattern, i, fluid);
                        }
                    }
                }
            } else {
                for (int i = 0; i < 9; ++i) {
                    ItemStack ingredient = matrix.func_70301_a(i);

                    if (!ingredient.func_190926_b()) {
                        ItemPattern.setInputSlot(pattern, i, ingredient);
                    }
                }
            }

            patterns.setStackInSlot(1, pattern);
        }
    }

    private boolean isPatternAvailable() {
        return !(patterns.getStackInSlot(0).func_190926_b() && patterns.getStackInSlot(1).func_190926_b());
    }

    public boolean canCreatePattern() {
        if (!isPatternAvailable()) {
            return false;
        }

        if (isProcessingPattern()) {
            int inputsFilled = 0;
            int outputsFilled = 0;

            for (int i = 0; i < 9; ++i) {
                if (!processingMatrix.getStackInSlot(i).func_190926_b()) {
                    inputsFilled++;
                }

                if (processingMatrixFluids.getFluid(i) != null) {
                    inputsFilled++;
                }
            }

            for (int i = 9; i < 18; ++i) {
                if (!processingMatrix.getStackInSlot(i).func_190926_b()) {
                    outputsFilled++;
                }

                if (processingMatrixFluids.getFluid(i) != null) {
                    outputsFilled++;
                }
            }

            return inputsFilled > 0 && outputsFilled > 0;
        } else {
            return !result.func_70301_a(0).func_190926_b() && isPatternAvailable();
        }
    }

    @Override
    public int getViewType() {
        return world.field_72995_K ? TileGrid.VIEW_TYPE.getValue() : viewType;
    }

    @Override
    public int getSortingDirection() {
        return world.field_72995_K ? TileGrid.SORTING_DIRECTION.getValue() : sortingDirection;
    }

    @Override
    public int getSortingType() {
        return world.field_72995_K ? TileGrid.SORTING_TYPE.getValue() : sortingType;
    }

    @Override
    public int getSearchBoxMode() {
        return world.field_72995_K ? TileGrid.SEARCH_BOX_MODE.getValue() : searchBoxMode;
    }

    @Override
    public int getSize() {
        return world.field_72995_K ? TileGrid.SIZE.getValue() : size;
    }

    @Override
    public int getTabSelected() {
        return world.field_72995_K ? TileGrid.TAB_SELECTED.getValue() : tabSelected;
    }

    @Override
    public int getTabPage() {
        return world.field_72995_K ? TileGrid.TAB_PAGE.getValue() : Math.min(tabPage, getTotalTabPages());
    }

    @Override
    public int getTotalTabPages() {
        return (int) Math.floor((float) Math.max(0, tabs.size() - 1) / (float) IGrid.TABS_PER_PAGE);
    }

    @Override
    public void onViewTypeChanged(int type) {
        TileDataManager.setParameter(TileGrid.VIEW_TYPE, type);
    }

    @Override
    public void onSortingTypeChanged(int type) {
        TileDataManager.setParameter(TileGrid.SORTING_TYPE, type);
    }

    @Override
    public void onSortingDirectionChanged(int direction) {
        TileDataManager.setParameter(TileGrid.SORTING_DIRECTION, direction);
    }

    @Override
    public void onSearchBoxModeChanged(int searchBoxMode) {
        TileDataManager.setParameter(TileGrid.SEARCH_BOX_MODE, searchBoxMode);
    }

    @Override
    public void onSizeChanged(int size) {
        TileDataManager.setParameter(TileGrid.SIZE, size);
    }

    @Override
    public void onTabSelectionChanged(int tab) {
        TileDataManager.setParameter(TileGrid.TAB_SELECTED, tab);
    }

    @Override
    public void onTabPageChanged(int page) {
        if (page >= 0 && page <= getTotalTabPages()) {
            TileDataManager.setParameter(TileGrid.TAB_PAGE, page);
        }
    }

    @Override
    public int getType() {
        return world.field_72995_K ? TileGrid.PROCESSING_TYPE.getValue() : processingType;
    }

    @Override
    public void setType(int type) {
        this.processingType = type;

        this.markDirty();
    }

    @Override
    public IItemHandlerModifiable getItemFilters() {
        return processingMatrix;
    }

    @Override
    public FluidInventory getFluidFilters() {
        return processingMatrixFluids;
    }

    @Override
    public boolean hasConnectivityState() {
        return true;
    }

    @Override
    public void read(NBTTagCompound tag) {
        super.read(tag);

        StackUtils.readItems(matrix, 0, tag);
        StackUtils.readItems(patterns, 1, tag);
        StackUtils.readItems(filter, 2, tag);
        StackUtils.readItems(processingMatrix, 3, tag);

        if (tag.func_74764_b(NBT_PROCESSING_MATRIX_FLUIDS)) {
            processingMatrixFluids.readFromNbt(tag.func_74775_l(NBT_PROCESSING_MATRIX_FLUIDS));
        }

        if (tag.func_74764_b(NBT_TAB_SELECTED)) {
            tabSelected = tag.func_74762_e(NBT_TAB_SELECTED);
        }

        if (tag.func_74764_b(NBT_TAB_PAGE)) {
            tabPage = tag.func_74762_e(NBT_TAB_PAGE);
        }
    }

    @Override
    public String getId() {
        return ID;
    }

    @Override
    public NBTTagCompound write(NBTTagCompound tag) {
        super.write(tag);

        StackUtils.writeItems(matrix, 0, tag);
        StackUtils.writeItems(patterns, 1, tag);
        StackUtils.writeItems(filter, 2, tag);
        StackUtils.writeItems(processingMatrix, 3, tag);

        tag.func_74782_a(NBT_PROCESSING_MATRIX_FLUIDS, processingMatrixFluids.writeToNbt());
        tag.func_74768_a(NBT_TAB_SELECTED, tabSelected);
        tag.func_74768_a(NBT_TAB_PAGE, tabPage);

        return tag;
    }

    @Override
    public NBTTagCompound writeConfiguration(NBTTagCompound tag) {
        super.writeConfiguration(tag);

        tag.func_74768_a(NBT_VIEW_TYPE, viewType);
        tag.func_74768_a(NBT_SORTING_DIRECTION, sortingDirection);
        tag.func_74768_a(NBT_SORTING_TYPE, sortingType);
        tag.func_74768_a(NBT_SEARCH_BOX_MODE, searchBoxMode);
        tag.func_74768_a(NBT_SIZE, size);

        tag.func_74757_a(NBT_OREDICT_PATTERN, oredictPattern);
        tag.func_74757_a(NBT_PROCESSING_PATTERN, processingPattern);
        tag.func_74768_a(NBT_PROCESSING_TYPE, processingType);

        return tag;
    }

    @Override
    public void readConfiguration(NBTTagCompound tag) {
        super.readConfiguration(tag);

        if (tag.func_74764_b(NBT_VIEW_TYPE)) {
            viewType = tag.func_74762_e(NBT_VIEW_TYPE);
        }

        if (tag.func_74764_b(NBT_SORTING_DIRECTION)) {
            sortingDirection = tag.func_74762_e(NBT_SORTING_DIRECTION);
        }

        if (tag.func_74764_b(NBT_SORTING_TYPE)) {
            sortingType = tag.func_74762_e(NBT_SORTING_TYPE);
        }

        if (tag.func_74764_b(NBT_SEARCH_BOX_MODE)) {
            searchBoxMode = tag.func_74762_e(NBT_SEARCH_BOX_MODE);
        }

        if (tag.func_74764_b(NBT_SIZE)) {
            size = tag.func_74762_e(NBT_SIZE);
        }

        if (tag.func_74764_b(NBT_OREDICT_PATTERN)) {
            oredictPattern = tag.func_74767_n(NBT_OREDICT_PATTERN);
        }

        if (tag.func_74764_b(NBT_PROCESSING_PATTERN)) {
            processingPattern = tag.func_74767_n(NBT_PROCESSING_PATTERN);
        }

        if (tag.func_74764_b(NBT_PROCESSING_TYPE)) {
            processingType = tag.func_74762_e(NBT_PROCESSING_TYPE);
        }
    }

    @Override
    public IItemHandler getDrops() {
        switch (getGridType()) {
            case CRAFTING:
                return new CombinedInvWrapper(filter, new InvWrapper(matrix));
            case PATTERN:
                return new CombinedInvWrapper(filter, patterns);
            default:
                return new CombinedInvWrapper(filter);
        }
    }
}
