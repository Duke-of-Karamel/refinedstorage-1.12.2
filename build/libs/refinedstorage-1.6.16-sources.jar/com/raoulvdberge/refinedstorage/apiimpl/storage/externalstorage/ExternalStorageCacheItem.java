package com.raoulvdberge.refinedstorage.apiimpl.storage.externalstorage;

import com.raoulvdberge.refinedstorage.api.network.INetwork;
import com.raoulvdberge.refinedstorage.apiimpl.API;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public class ExternalStorageCacheItem {
    private List<ItemStack> cache;

    public void update(INetwork network, @Nullable IItemHandler handler) {
        if (handler == null) {
            return;
        }

        if (cache == null) {
            cache = new ArrayList<>();

            for (int i = 0; i < handler.getSlots(); ++i) {
                cache.add(handler.getStackInSlot(i).func_77946_l());
            }

            return;
        }

        for (int i = 0; i < handler.getSlots(); ++i) {
            ItemStack actual = handler.getStackInSlot(i);

            if (i >= cache.size()) { // ENLARGED
                if (!actual.func_190926_b()) {
                    network.getItemStorageCache().add(actual, actual.func_190916_E(), false, true);

                    cache.add(actual.func_77946_l());
                }

                continue;
            }

            ItemStack cached = cache.get(i);

            if (!cached.func_190926_b() && actual.func_190926_b()) { // REMOVED
                network.getItemStorageCache().remove(cached, cached.func_190916_E(), true);

                cache.set(i, ItemStack.field_190927_a);
            } else if (cached.func_190926_b() && !actual.func_190926_b()) { // ADDED
                network.getItemStorageCache().add(actual, actual.func_190916_E(), false, true);

                cache.set(i, actual.func_77946_l());
            } else if (!API.instance().getComparer().isEqualNoQuantity(cached, actual)) { // CHANGED
                network.getItemStorageCache().remove(cached, cached.func_190916_E(), true);
                network.getItemStorageCache().add(actual, actual.func_190916_E(), false, true);

                cache.set(i, actual.func_77946_l());
            } else if (cached.func_190916_E() != actual.func_190916_E()) { // COUNT_CHANGED
                int delta = actual.func_190916_E() - cached.func_190916_E();

                if (delta > 0) {
                    network.getItemStorageCache().add(actual, delta, false, true);

                    cached.func_190917_f(delta);
                } else {
                    network.getItemStorageCache().remove(actual, Math.abs(delta), true);

                    cached.func_190918_g(Math.abs(delta));
                }
            }
        }

        if (cache.size() > handler.getSlots()) { // SHRUNK
            for (int i = cache.size() - 1; i >= handler.getSlots(); --i) { // Reverse order for the remove call.
                ItemStack cached = cache.get(i);

                if (!cached.func_190926_b()) {
                    network.getItemStorageCache().remove(cached, cached.func_190916_E(), true);
                }

                cache.remove(i);
            }
        }

        network.getItemStorageCache().flush();
    }
}
