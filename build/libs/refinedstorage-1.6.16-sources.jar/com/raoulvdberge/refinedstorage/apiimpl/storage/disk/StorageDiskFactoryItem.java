package com.raoulvdberge.refinedstorage.apiimpl.storage.disk;

import com.raoulvdberge.refinedstorage.api.storage.disk.IStorageDisk;
import com.raoulvdberge.refinedstorage.api.storage.disk.IStorageDiskFactory;
import com.raoulvdberge.refinedstorage.util.StackUtils;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.World;

public class StorageDiskFactoryItem implements IStorageDiskFactory<ItemStack> {
    public static final String ID = "normal_item";

    @Override
    public IStorageDisk<ItemStack> createFromNbt(World world, NBTTagCompound tag) {
        StorageDiskItem disk = new StorageDiskItem(world, tag.func_74762_e(StorageDiskItem.NBT_CAPACITY));

        NBTTagList list = (NBTTagList) tag.func_74781_a(StorageDiskItem.NBT_ITEMS);

        for (int i = 0; i < list.func_74745_c(); ++i) {
            ItemStack stack = StackUtils.deserializeStackFromNbt(list.func_150305_b(i));

            if (!stack.func_190926_b()) {
                disk.getRawStacks().put(stack.func_77973_b(), stack);
            }
        }

        return disk;
    }

    @Override
    public IStorageDisk<ItemStack> create(World world, int capacity) {
        return new StorageDiskItem(world, capacity);
    }
}
