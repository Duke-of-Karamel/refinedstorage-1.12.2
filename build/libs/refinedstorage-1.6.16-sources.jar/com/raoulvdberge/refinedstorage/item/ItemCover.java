package com.raoulvdberge.refinedstorage.item;

import com.raoulvdberge.refinedstorage.RS;
import com.raoulvdberge.refinedstorage.api.network.node.INetworkNode;
import com.raoulvdberge.refinedstorage.api.network.security.Permission;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.ICoverable;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.cover.Cover;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.cover.CoverManager;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.cover.CoverType;
import com.raoulvdberge.refinedstorage.item.info.IItemInfo;
import com.raoulvdberge.refinedstorage.item.info.ItemInfo;
import com.raoulvdberge.refinedstorage.render.IModelRegistration;
import com.raoulvdberge.refinedstorage.render.model.loader.CustomModelLoaderCover;
import com.raoulvdberge.refinedstorage.tile.TileNode;
import com.raoulvdberge.refinedstorage.util.WorldUtils;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

public class ItemCover extends ItemBase {
    private static final String NBT_ITEM = "Item";

    public static final ItemStack HIDDEN_COVER_ALTERNATIVE = new ItemStack(Blocks.field_150417_aV);

    public ItemCover(IItemInfo info) {
        super(info);

        func_77637_a(RS.INSTANCE.coversTab);
    }

    public ItemCover() {
        this(new ItemInfo(RS.ID, "cover"));
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerModels(IModelRegistration modelRegistration) {
        modelRegistration.setModel(this, 0, new ModelResourceLocation(info.getId(), "inventory"));

        modelRegistration.addModelLoader(() -> new CustomModelLoaderCover()); // Don't use a method reference here, it crashes the server!
    }

    public static void setItem(ItemStack cover, ItemStack item) {
        if (!cover.func_77942_o()) {
            cover.func_77982_d(new NBTTagCompound());
        }

        cover.func_77978_p().func_74782_a(NBT_ITEM, item.serializeNBT());
    }

    @Nonnull
    public static ItemStack getItem(ItemStack cover) {
        if (!cover.func_77942_o() || !cover.func_77978_p().func_74764_b(NBT_ITEM)) {
            return ItemStack.field_190927_a;
        }

        return new ItemStack(cover.func_77978_p().func_74775_l(NBT_ITEM));
    }

    @Override
    public void func_77624_a(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        super.func_77624_a(stack, world, tooltip, flag);

        ItemStack item = getItem(stack);

        if (!item.func_190926_b()) {
            tooltip.add(item.func_77973_b().func_77653_i(item));
        }
    }

    @Override
    public void func_150895_a(CreativeTabs tab, NonNullList<ItemStack> items) {
        if (!func_194125_a(tab)) {
            return;
        }

        if (RS.INSTANCE.config.hideCovers) {
            ItemStack stack = new ItemStack(this);

            setItem(stack, HIDDEN_COVER_ALTERNATIVE);

            items.add(stack);

            return;
        }

        for (Block block : Block.field_149771_c) {
            Item item = Item.func_150898_a(block);

            if (item == Items.field_190931_a) {
                continue;
            }

            NonNullList<ItemStack> subBlocks = NonNullList.func_191196_a();

            block.func_149666_a(CreativeTabs.field_78027_g, subBlocks);

            for (ItemStack subBlock : subBlocks) {
                if (CoverManager.isValidCover(subBlock)) {
                    ItemStack stack = new ItemStack(this);

                    setItem(stack, subBlock);

                    items.add(stack);
                }
            }
        }
    }

    @Override
    public EnumActionResult func_180614_a(EntityPlayer player, World world, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        ItemStack stack = player.func_184586_b(hand);

        TileEntity tile = world.func_175625_s(pos);

        // Support placing on the bottom side without too much hassle.
        if (!canPlaceOn(tile)) {
            pos = pos.func_177984_a();

            facing = EnumFacing.DOWN;

            tile = world.func_175625_s(pos);
        }

        if (canPlaceOn(tile)) {
            if (world.field_72995_K) {
                return EnumActionResult.SUCCESS;
            }

            INetworkNode node = ((TileNode) tile).getNode();

            if (node.getNetwork() != null && !node.getNetwork().getSecurityManager().hasPermission(Permission.BUILD, player)) {
                WorldUtils.sendNoPermissionMessage(player);

                return EnumActionResult.FAIL;
            }

            if (((ICoverable) node).getCoverManager().setCover(facing, createCover(getItem(stack)))) {
                player.func_184586_b(hand).func_190918_g(1);

                WorldUtils.updateBlock(world, pos);

                return EnumActionResult.SUCCESS;
            }

            return EnumActionResult.FAIL;
        }

        return EnumActionResult.PASS;
    }

    private boolean canPlaceOn(TileEntity tile) {
        return tile instanceof TileNode && ((TileNode) tile).getNode() instanceof ICoverable;
    }

    protected Cover createCover(ItemStack stack) {
        return new Cover(stack, CoverType.NORMAL);
    }
}
