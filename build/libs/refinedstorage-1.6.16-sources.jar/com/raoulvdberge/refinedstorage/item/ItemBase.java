package com.raoulvdberge.refinedstorage.item;

import com.raoulvdberge.refinedstorage.RS;
import com.raoulvdberge.refinedstorage.item.info.IItemInfo;
import com.raoulvdberge.refinedstorage.render.IModelRegistration;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public abstract class ItemBase extends Item {
    protected final IItemInfo info;

    public ItemBase(IItemInfo info) {
        this.info = info;

        setRegistryName(info.getId());
        func_77637_a(RS.INSTANCE.tab);
    }

    @SideOnly(Side.CLIENT)
    public void registerModels(IModelRegistration modelRegistration) {
    }

    @Override
    public String func_77658_a() {
        return "item." + info.getId().toString();
    }

    @Override
    public String func_77667_c(ItemStack stack) {
        if (func_77614_k()) {
            return func_77658_a() + "." + stack.func_77952_i();
        }

        return func_77658_a();
    }
}
