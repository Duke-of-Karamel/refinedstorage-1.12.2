package com.raoulvdberge.refinedstorage.item.itemblock;

import com.raoulvdberge.refinedstorage.block.BlockBase;
import com.raoulvdberge.refinedstorage.tile.TileBase;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemBlockBase extends ItemBlock {
    private BlockBase block;

    public ItemBlockBase(BlockBase block, boolean subtypes) {
        super(block);

        this.block = block;

        setRegistryName(block.getInfo().getId());

        if (subtypes) {
            func_77656_e(0);
            func_77627_a(true);
        }
    }

    @Override
    public int func_77647_b(int damage) {
        return damage;
    }

    @Override
    public String func_77667_c(ItemStack stack) {
        if (func_77614_k()) {
            return func_77658_a() + "." + stack.func_77952_i();
        }

        return func_77658_a();
    }

    @Override
    public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ, IBlockState newState) {
        boolean result = super.placeBlockAt(stack, player, world, pos, side, hitX, hitY, hitZ, newState);

        if (result && block.getDirection() != null) {
            TileEntity tile = world.func_175625_s(pos);

            if (tile instanceof TileBase) {
                ((TileBase) tile).setDirection(block.getDirection().getFrom(side, pos, player));
            }
        }

        return result;
    }
}
