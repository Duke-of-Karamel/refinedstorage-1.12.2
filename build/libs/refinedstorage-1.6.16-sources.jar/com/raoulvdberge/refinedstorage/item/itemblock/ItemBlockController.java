package com.raoulvdberge.refinedstorage.item.itemblock;

import com.raoulvdberge.refinedstorage.RS;
import com.raoulvdberge.refinedstorage.block.BlockController;
import com.raoulvdberge.refinedstorage.block.enums.ControllerType;
import com.raoulvdberge.refinedstorage.tile.TileController;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class ItemBlockController extends ItemBlockBase {
    public ItemBlockController(BlockController block) {
        super(block, true);

        func_77625_d(1);
    }

    @Override
    public double getDurabilityForDisplay(ItemStack stack) {
        return 1D - ((double) getEnergyStored(stack) / (double) RS.INSTANCE.config.controllerCapacity);
    }

    @Override
    public int getRGBDurabilityForDisplay(ItemStack stack) {
        return MathHelper.func_181758_c(Math.max(0.0F, (float) getEnergyStored(stack) / (float) RS.INSTANCE.config.controllerCapacity) / 3.0F, 1.0F, 1.0F);
    }

    @Override
    public boolean showDurabilityBar(ItemStack stack) {
        return stack.func_77960_j() != ControllerType.CREATIVE.getId();
    }

    @Override
    public void func_77624_a(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        super.func_77624_a(stack, world, tooltip, flag);

        if (stack.func_77960_j() != ControllerType.CREATIVE.getId()) {
            tooltip.add(I18n.func_135052_a("misc.refinedstorage:energy_stored", getEnergyStored(stack), RS.INSTANCE.config.controllerCapacity));
        }
    }

    public static int getEnergyStored(ItemStack stack) {
        return (stack.func_77942_o() && stack.func_77978_p().func_74764_b(TileController.NBT_ENERGY)) ? stack.func_77978_p().func_74762_e(TileController.NBT_ENERGY) : 0;
    }

    @Override
    public void func_77622_d(ItemStack stack, World world, EntityPlayer player) {
        super.func_77622_d(stack, world, player);

        createStack(stack, 0);
    }

    public static ItemStack createStack(ItemStack stack, int energy) {
        NBTTagCompound tag = stack.func_77978_p();

        if (tag == null) {
            tag = new NBTTagCompound();
        }

        tag.func_74768_a(TileController.NBT_ENERGY, stack.func_77960_j() == ControllerType.CREATIVE.getId() ? RS.INSTANCE.config.controllerCapacity : energy);

        stack.func_77982_d(tag);

        return stack;
    }
}
