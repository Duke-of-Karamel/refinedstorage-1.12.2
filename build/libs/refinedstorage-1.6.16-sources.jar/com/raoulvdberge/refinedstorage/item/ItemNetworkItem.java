package com.raoulvdberge.refinedstorage.item;

import com.raoulvdberge.refinedstorage.RSBlocks;
import com.raoulvdberge.refinedstorage.api.network.INetwork;
import com.raoulvdberge.refinedstorage.api.network.item.INetworkItemProvider;
import com.raoulvdberge.refinedstorage.item.info.IItemInfo;
import com.raoulvdberge.refinedstorage.render.IModelRegistration;
import net.minecraft.block.Block;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Consumer;

public abstract class ItemNetworkItem extends ItemEnergyItem implements INetworkItemProvider {
    private static final String NBT_CONTROLLER_X = "ControllerX";
    private static final String NBT_CONTROLLER_Y = "ControllerY";
    private static final String NBT_CONTROLLER_Z = "ControllerZ";
    private static final String NBT_DIMENSION_ID = "DimensionID";

    public ItemNetworkItem(IItemInfo info, int energyCapacity) {
        super(info, energyCapacity);

        func_185043_a(new ResourceLocation("connected"), (stack, world, entity) -> (entity != null && isValid(stack)) ? 1.0f : 0.0f);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerModels(IModelRegistration modelRegistration) {

    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.func_184586_b(hand);

        if (!world.field_72995_K) {
            applyNetwork(stack, n -> n.getNetworkItemHandler().open(player, player.func_184586_b(hand), player.field_71071_by.field_70461_c), player::func_145747_a);
        }

        return ActionResult.newResult(EnumActionResult.SUCCESS, stack);
    }

    public void applyNetwork(ItemStack stack, Consumer<INetwork> networkConsumer, Consumer<TextComponentTranslation> errorConsumer) {
        if (!isValid(stack)) {
            errorConsumer.accept(new TextComponentTranslation("misc.refinedstorage:network_item.not_found"));
        } else {
            World networkWorld = DimensionManager.getWorld(getDimensionId(stack));

            TileEntity network;

            if (networkWorld != null && ((network = networkWorld.func_175625_s(new BlockPos(getX(stack), getY(stack), getZ(stack)))) instanceof INetwork)) {
                networkConsumer.accept((INetwork) network);
            } else {
                errorConsumer.accept(new TextComponentTranslation("misc.refinedstorage:network_item.not_found"));
            }
        }
    }

    @Override
    public void func_77624_a(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        super.func_77624_a(stack, world, tooltip, flag);

        if (isValid(stack)) {
            tooltip.add(I18n.func_135052_a("misc.refinedstorage:network_item.tooltip", getX(stack), getY(stack), getZ(stack)));
        }
    }

    @Override
    public EnumActionResult func_180614_a(EntityPlayer player, World world, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        ItemStack stack = player.func_184586_b(hand);

        Block block = world.func_180495_p(pos).func_177230_c();

        if (block == RSBlocks.CONTROLLER) {
            NBTTagCompound tag = stack.func_77978_p();

            if (tag == null) {
                tag = new NBTTagCompound();
            }

            tag.func_74768_a(NBT_CONTROLLER_X, pos.func_177958_n());
            tag.func_74768_a(NBT_CONTROLLER_Y, pos.func_177956_o());
            tag.func_74768_a(NBT_CONTROLLER_Z, pos.func_177952_p());
            tag.func_74768_a(NBT_DIMENSION_ID, player.field_71093_bK);

            stack.func_77982_d(tag);

            return EnumActionResult.SUCCESS;
        }

        return EnumActionResult.PASS;
    }

    public static int getDimensionId(ItemStack stack) {
        return stack.func_77978_p().func_74762_e(NBT_DIMENSION_ID);
    }

    public static int getX(ItemStack stack) {
        return stack.func_77978_p().func_74762_e(NBT_CONTROLLER_X);
    }

    public static int getY(ItemStack stack) {
        return stack.func_77978_p().func_74762_e(NBT_CONTROLLER_Y);
    }

    public static int getZ(ItemStack stack) {
        return stack.func_77978_p().func_74762_e(NBT_CONTROLLER_Z);
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return false;
    }

    public boolean isValid(ItemStack stack) {
        return stack.func_77942_o()
            && stack.func_77978_p().func_74764_b(NBT_CONTROLLER_X)
            && stack.func_77978_p().func_74764_b(NBT_CONTROLLER_Y)
            && stack.func_77978_p().func_74764_b(NBT_CONTROLLER_Z)
            && stack.func_77978_p().func_74764_b(NBT_DIMENSION_ID);
    }
}
