package com.raoulvdberge.refinedstorage.block;

import com.raoulvdberge.refinedstorage.RSGui;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.storage.NetworkNodeFluidStorage;
import com.raoulvdberge.refinedstorage.block.enums.FluidStorageType;
import com.raoulvdberge.refinedstorage.block.info.BlockInfoBuilder;
import com.raoulvdberge.refinedstorage.item.itemblock.ItemBlockFluidStorage;
import com.raoulvdberge.refinedstorage.render.IModelRegistration;
import com.raoulvdberge.refinedstorage.tile.TileFluidStorage;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockFluidStorage extends BlockNode {
    public static final PropertyEnum TYPE = PropertyEnum.func_177709_a("type", FluidStorageType.class);

    public BlockFluidStorage() {
        super(BlockInfoBuilder.forId("fluid_storage").hardness(5.8F).tileEntity(TileFluidStorage::new).create());
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerModels(IModelRegistration modelRegistration) {
        modelRegistration.setModel(this, FluidStorageType.TYPE_64K.getId(), new ModelResourceLocation(info.getId(), "type=64k"));
        modelRegistration.setModel(this, FluidStorageType.TYPE_256K.getId(), new ModelResourceLocation(info.getId(), "type=256k"));
        modelRegistration.setModel(this, FluidStorageType.TYPE_1024K.getId(), new ModelResourceLocation(info.getId(), "type=1024k"));
        modelRegistration.setModel(this, FluidStorageType.TYPE_4096K.getId(), new ModelResourceLocation(info.getId(), "type=4096k"));
        modelRegistration.setModel(this, FluidStorageType.TYPE_CREATIVE.getId(), new ModelResourceLocation(info.getId(), "type=creative"));
    }

    @Override
    public void func_149666_a(CreativeTabs tab, NonNullList<ItemStack> items) {
        for (int i = 0; i <= 4; ++i) {
            items.add(new ItemStack(this, 1, i));
        }
    }

    @Override
    protected BlockStateContainer func_180661_e() {
        return createBlockStateBuilder()
            .add(TYPE)
            .build();
    }

    @Override
    public IBlockState func_176203_a(int meta) {
        return func_176223_P().func_177226_a(TYPE, FluidStorageType.getById(meta));
    }

    @Override
    public int func_176201_c(IBlockState state) {
        return ((FluidStorageType) state.func_177229_b(TYPE)).getId();
    }

    @Override
    public boolean func_180639_a(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing side, float hitX, float hitY, float hitZ) {
        return openNetworkGui(RSGui.FLUID_STORAGE, player, world, pos, side);
    }

    @Override
    public Item createItem() {
        return new ItemBlockFluidStorage(this);
    }

    @Override
    public void func_180633_a(World world, BlockPos pos, IBlockState state, EntityLivingBase player, ItemStack stack) {
        if (!world.field_72995_K) {
            NetworkNodeFluidStorage storage = ((TileFluidStorage) world.func_175625_s(pos)).getNode();

            if (stack.func_77942_o() && stack.func_77978_p().func_186855_b(NetworkNodeFluidStorage.NBT_ID)) {
                storage.setStorageId(stack.func_77978_p().func_186857_a(NetworkNodeFluidStorage.NBT_ID));
            }

            storage.loadStorage();
        }

        // Call this after loading the storage, so the network discovery can use the loaded storage.
        super.func_180633_a(world, pos, state, player, stack);
    }

    @Override
    public void getDrops(NonNullList<ItemStack> drops, IBlockAccess world, BlockPos pos, IBlockState state, int fortune) {
        TileFluidStorage storage = (TileFluidStorage) world.func_175625_s(pos);

        ItemStack stack = new ItemStack(this, 1, func_176201_c(state));

        stack.func_77982_d(new NBTTagCompound());
        stack.func_77978_p().func_186854_a(NetworkNodeFluidStorage.NBT_ID, storage.getNode().getStorageId());

        drops.add(stack);
    }
}
