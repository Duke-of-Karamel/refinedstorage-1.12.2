package com.raoulvdberge.refinedstorage.block.info;

import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

import java.util.Arrays;

public enum BlockDirection {
    ANY(EnumFacing.field_82609_l),
    ANY_FACE_PLAYER(EnumFacing.field_82609_l),
    HORIZONTAL(EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST);

    private final PropertyDirection property;

    BlockDirection(EnumFacing... allowed) {
        this.property = PropertyDirection.func_177713_a("direction", Arrays.asList(allowed));
    }

    public PropertyDirection getProperty() {
        return property;
    }

    public EnumFacing getFrom(EnumFacing facing, BlockPos pos, EntityLivingBase entity) {
        switch (this) {
            case ANY:
                return facing.func_176734_d();
            case ANY_FACE_PLAYER:
                return EnumFacing.func_190914_a(pos, entity);
            case HORIZONTAL:
                return entity.func_174811_aO().func_176734_d();
            default:
                return null;
        }
    }

    public EnumFacing cycle(EnumFacing previous) {
        switch (this) {
            case ANY:
            case ANY_FACE_PLAYER:
                return previous.ordinal() + 1 >= EnumFacing.field_82609_l.length ? EnumFacing.field_82609_l[0] : EnumFacing.field_82609_l[previous.ordinal() + 1];
            case HORIZONTAL:
                return previous.func_176735_f();
            default:
                return previous;
        }
    }
}
