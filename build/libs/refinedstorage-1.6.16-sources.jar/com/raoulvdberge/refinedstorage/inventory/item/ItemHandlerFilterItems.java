package com.raoulvdberge.refinedstorage.inventory.item;

import com.raoulvdberge.refinedstorage.util.StackUtils;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import net.minecraftforge.items.ItemStackHandler;

public class ItemHandlerFilterItems extends ItemStackHandler {
    private ItemStack stack;

    public ItemHandlerFilterItems(ItemStack stack) {
        super(27);

        this.stack = stack;

        if (stack.func_77942_o()) {
            StackUtils.readItems(this, 0, stack.func_77978_p());
        }
    }

    @Override
    protected void onContentsChanged(int slot) {
        super.onContentsChanged(slot);

        if (!stack.func_77942_o()) {
            stack.func_77982_d(new NBTTagCompound());
        }

        StackUtils.writeItems(this, 0, stack.func_77978_p());
    }

    public NonNullList<ItemStack> getFilteredItems() {
        return stacks;
    }
}
