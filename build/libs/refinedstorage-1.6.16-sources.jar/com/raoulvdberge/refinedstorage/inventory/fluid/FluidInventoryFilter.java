package com.raoulvdberge.refinedstorage.inventory.fluid;

import com.raoulvdberge.refinedstorage.item.ItemFilter;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import net.minecraftforge.fluids.FluidStack;

public class FluidInventoryFilter extends FluidInventory {
    public FluidInventoryFilter(ItemStack stack) {
        super(27, Integer.MAX_VALUE, null);

        this.listener = slot -> {
            if (!stack.func_77942_o()) {
                stack.func_77982_d(new NBTTagCompound());
            }

            stack.func_77978_p().func_74782_a(ItemFilter.NBT_FLUID_FILTERS, writeToNbt());
        };

        if (stack.func_77942_o() && stack.func_77978_p().func_74764_b(ItemFilter.NBT_FLUID_FILTERS)) {
            readFromNbt(stack.func_77978_p().func_74775_l(ItemFilter.NBT_FLUID_FILTERS));
        }
    }

    public NonNullList<FluidStack> getFilteredFluids() {
        NonNullList<FluidStack> list = NonNullList.func_191196_a();

        for (FluidStack fluid : this.getFluids()) {
            if (fluid != null) {
                list.add(fluid);
            }
        }

        return list;
    }
}
