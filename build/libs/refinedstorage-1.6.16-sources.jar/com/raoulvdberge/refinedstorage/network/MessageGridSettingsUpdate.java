package com.raoulvdberge.refinedstorage.network;

import com.raoulvdberge.refinedstorage.api.network.grid.IGrid;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.NetworkNodeGrid;
import com.raoulvdberge.refinedstorage.container.ContainerGrid;
import com.raoulvdberge.refinedstorage.tile.grid.WirelessGrid;
import com.raoulvdberge.refinedstorage.tile.grid.portable.PortableGrid;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

public class MessageGridSettingsUpdate extends MessageHandlerPlayerToServer<MessageGridSettingsUpdate> implements IMessage {
    private int viewType;
    private int sortingDirection;
    private int sortingType;
    private int searchBoxMode;
    private int size;
    private int tabSelected;
    private int tabPage;

    public MessageGridSettingsUpdate() {
    }

    public MessageGridSettingsUpdate(int viewType, int sortingDirection, int sortingType, int searchBoxMode, int size, int tabSelected, int tabPage) {
        this.viewType = viewType;
        this.sortingDirection = sortingDirection;
        this.sortingType = sortingType;
        this.searchBoxMode = searchBoxMode;
        this.size = size;
        this.tabSelected = tabSelected;
        this.tabPage = tabPage;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        viewType = buf.readInt();
        sortingDirection = buf.readInt();
        sortingType = buf.readInt();
        searchBoxMode = buf.readInt();
        size = buf.readInt();
        tabSelected = buf.readInt();
        tabPage = buf.readInt();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(viewType);
        buf.writeInt(sortingDirection);
        buf.writeInt(sortingType);
        buf.writeInt(searchBoxMode);
        buf.writeInt(size);
        buf.writeInt(tabSelected);
        buf.writeInt(tabPage);
    }

    @Override
    public void handle(MessageGridSettingsUpdate message, EntityPlayerMP player) {
        if (player.field_71070_bA instanceof ContainerGrid) {
            IGrid grid = ((ContainerGrid) player.field_71070_bA).getGrid();

            if (grid instanceof WirelessGrid || grid instanceof PortableGrid) {
                ItemStack stack = grid instanceof WirelessGrid ? ((WirelessGrid) grid).getStack() : ((PortableGrid) grid).getStack();

                if (!stack.func_77942_o()) {
                    stack.func_77982_d(new NBTTagCompound());
                }

                if (IGrid.isValidViewType(message.viewType)) {
                    stack.func_77978_p().func_74768_a(NetworkNodeGrid.NBT_VIEW_TYPE, message.viewType);
                }

                if (IGrid.isValidSortingDirection(message.sortingDirection)) {
                    stack.func_77978_p().func_74768_a(NetworkNodeGrid.NBT_SORTING_DIRECTION, message.sortingDirection);
                }

                if (IGrid.isValidSortingType(message.sortingType)) {
                    stack.func_77978_p().func_74768_a(NetworkNodeGrid.NBT_SORTING_TYPE, message.sortingType);
                }

                if (IGrid.isValidSearchBoxMode(message.searchBoxMode)) {
                    stack.func_77978_p().func_74768_a(NetworkNodeGrid.NBT_SEARCH_BOX_MODE, message.searchBoxMode);
                }

                if (IGrid.isValidSize(message.size)) {
                    stack.func_77978_p().func_74768_a(NetworkNodeGrid.NBT_SIZE, message.size);
                }

                stack.func_77978_p().func_74768_a(NetworkNodeGrid.NBT_TAB_SELECTED, message.tabSelected);
                stack.func_77978_p().func_74768_a(NetworkNodeGrid.NBT_TAB_PAGE, message.tabPage);
            }
        }
    }
}
