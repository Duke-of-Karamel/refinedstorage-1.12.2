package com.raoulvdberge.refinedstorage.network;

import com.raoulvdberge.refinedstorage.RSBlocks;
import com.raoulvdberge.refinedstorage.apiimpl.API;
import com.raoulvdberge.refinedstorage.item.ItemNetworkItem;
import com.raoulvdberge.refinedstorage.tile.grid.portable.PortableGrid;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

public class MessageNetworkItemOpen extends MessageHandlerPlayerToServer<MessageNetworkItemOpen> implements IMessage {
    private int slotId;

    public MessageNetworkItemOpen() {
    }

    public MessageNetworkItemOpen(int slotId) {
        this.slotId = slotId;
    }

    @Override
    protected void handle(MessageNetworkItemOpen message, EntityPlayerMP player) {
        ItemStack stack = player.field_71071_by.func_70301_a(message.slotId);

        if (stack.func_77973_b() instanceof ItemNetworkItem) {
            ((ItemNetworkItem) stack.func_77973_b()).applyNetwork(stack, n -> n.getNetworkItemHandler().open(player, stack, message.slotId), player::func_145747_a);
        } else if (stack.func_77973_b() == Item.func_150898_a(RSBlocks.PORTABLE_GRID)) { // @Hack
            API.instance().getGridManager().openGrid(PortableGrid.ID, player, stack, message.slotId);
        }
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        slotId = buf.readInt();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(slotId);
    }
}
