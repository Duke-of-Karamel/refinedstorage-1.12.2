package com.raoulvdberge.refinedstorage.network;

import com.raoulvdberge.refinedstorage.container.ContainerCrafterManager;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.IContainerListener;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

public class MessageCrafterManagerRequestSlotData extends MessageHandlerPlayerToServer<MessageCrafterManagerRequestSlotData> implements IMessage {
    @Override
    public void fromBytes(ByteBuf buf) {
    }

    @Override
    public void toBytes(ByteBuf buf) {
    }

    @Override
    protected void handle(MessageCrafterManagerRequestSlotData message, EntityPlayerMP player) {
        if (player.field_71070_bA instanceof ContainerCrafterManager) {
            for (IContainerListener listener : ((ContainerCrafterManager) player.field_71070_bA).getListeners()) {
                if (listener instanceof ContainerCrafterManager.CrafterManagerListener) {
                    ContainerCrafterManager.CrafterManagerListener cmListener = (ContainerCrafterManager.CrafterManagerListener) listener;

                    if (cmListener.getPlayer() == player) {
                        cmListener.setReceivedContainerData();
                        cmListener.func_71110_a(player.field_71070_bA, player.field_71070_bA.func_75138_a());
                    }
                }
            }
        }
    }
}
