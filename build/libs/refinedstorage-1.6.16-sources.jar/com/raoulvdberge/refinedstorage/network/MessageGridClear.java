package com.raoulvdberge.refinedstorage.network;

import com.raoulvdberge.refinedstorage.api.network.grid.GridType;
import com.raoulvdberge.refinedstorage.api.network.grid.IGridNetworkAware;
import com.raoulvdberge.refinedstorage.api.network.security.Permission;
import com.raoulvdberge.refinedstorage.api.util.Action;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.NetworkNodeGrid;
import com.raoulvdberge.refinedstorage.container.ContainerGrid;
import com.raoulvdberge.refinedstorage.util.StackUtils;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

public class MessageGridClear extends MessageHandlerPlayerToServer<MessageGridClear> implements IMessage {
    public MessageGridClear() {
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        // NO OP
    }

    @Override
    public void toBytes(ByteBuf buf) {
        // NO OP
    }

    @Override
    public void handle(MessageGridClear message, EntityPlayerMP player) {
        Container container = player.field_71070_bA;

        if (container instanceof ContainerGrid && ((ContainerGrid) container).getGrid() instanceof IGridNetworkAware) {
            IGridNetworkAware grid = (IGridNetworkAware) ((ContainerGrid) container).getGrid();

            if (grid.getGridType() == GridType.CRAFTING && grid.getNetwork() != null && grid.getNetwork().getSecurityManager().hasPermission(Permission.INSERT, player)) {
                InventoryCrafting matrix = grid.getCraftingMatrix();

                for (int i = 0; i < matrix.func_70302_i_(); ++i) {
                    ItemStack slot = matrix.func_70301_a(i);

                    if (!slot.func_190926_b()) {
                        matrix.func_70299_a(i, StackUtils.nullToEmpty(grid.getNetwork().insertItem(slot, slot.func_190916_E(), Action.PERFORM)));

                        grid.getNetwork().getItemStorageTracker().changed(player, slot.func_77946_l());
                    }
                }
            } else if (grid.getGridType() == GridType.PATTERN) {
                ((NetworkNodeGrid) grid).clearMatrix();
            }
        }
    }
}
