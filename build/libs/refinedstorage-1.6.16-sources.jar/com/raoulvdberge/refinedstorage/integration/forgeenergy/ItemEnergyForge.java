package com.raoulvdberge.refinedstorage.integration.forgeenergy;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.energy.EnergyStorage;

public class ItemEnergyForge extends EnergyStorage {
    private static final String NBT_ENERGY = "Energy";

    private ItemStack stack;

    public ItemEnergyForge(ItemStack stack, int capacity) {
        super(capacity, Integer.MAX_VALUE, Integer.MAX_VALUE);

        this.stack = stack;
        this.energy = stack.func_77942_o() && stack.func_77978_p().func_74764_b(NBT_ENERGY) ? stack.func_77978_p().func_74762_e(NBT_ENERGY) : 0;
    }

    @Override
    public int receiveEnergy(int maxReceive, boolean simulate) {
        int received = super.receiveEnergy(maxReceive, simulate);

        if (received > 0 && !simulate) {
            if (!stack.func_77942_o()) {
                stack.func_77982_d(new NBTTagCompound());
            }

            stack.func_77978_p().func_74768_a(NBT_ENERGY, getEnergyStored());
        }

        return received;
    }

    @Override
    public int extractEnergy(int maxExtract, boolean simulate) {
        int extracted = super.extractEnergy(maxExtract, simulate);

        if (extracted > 0 && !simulate) {
            if (!stack.func_77942_o()) {
                stack.func_77982_d(new NBTTagCompound());
            }

            stack.func_77978_p().func_74768_a(NBT_ENERGY, getEnergyStored());
        }

        return extracted;
    }
}
