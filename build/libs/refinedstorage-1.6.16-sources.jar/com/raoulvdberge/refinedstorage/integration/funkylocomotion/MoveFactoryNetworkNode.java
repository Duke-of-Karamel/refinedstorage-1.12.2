package com.raoulvdberge.refinedstorage.integration.funkylocomotion;

import com.raoulvdberge.refinedstorage.api.network.node.INetworkNode;
import com.raoulvdberge.refinedstorage.api.network.node.INetworkNodeManager;
import com.raoulvdberge.refinedstorage.apiimpl.API;
import com.raoulvdberge.refinedstorage.apiimpl.network.node.NetworkNode;
import com.raoulvdberge.refinedstorage.tile.TileNode;
import com.rwtema.funkylocomotion.api.IMoveFactory;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class MoveFactoryNetworkNode implements IMoveFactory {
    private static final String NBT_DIRECTION = "Direction";
    private static final String NBT_NODE = "Node";
    private static final String NBT_NODE_ID = "NodeID";
    private static final String NBT_BLOCK = "Block";
    private static final String NBT_META = "Meta";
    private static final String NBT_TILE = "Tile";

    @Override
    public NBTTagCompound destroyBlock(World world, BlockPos pos) {
        INetworkNodeManager manager = API.instance().getNetworkNodeManager(world);

        INetworkNode node = manager.getNode(pos);

        TileNode tile = (TileNode) world.func_175625_s(pos);

        NBTTagCompound tag = new NBTTagCompound();

        tag.func_74768_a(NBT_DIRECTION, tile.getDirection().ordinal());
        tag.func_74782_a(NBT_NODE, node.write(new NBTTagCompound()));
        tag.func_74778_a(NBT_NODE_ID, node.getId());

        // Funky Locomotion requires this
        IBlockState state = world.func_180495_p(pos);
        tag.func_74778_a(NBT_BLOCK, Block.field_149771_c.func_177774_c(state.func_177230_c()).toString());
        tag.func_74768_a(NBT_META, state.func_177230_c().func_176201_c(state));
        tag.func_74782_a(NBT_TILE, tile.func_189515_b(new NBTTagCompound()));

        manager.removeNode(pos); // Avoid inventory dropping
        manager.markForSaving();

        return tag;
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean recreateBlock(World world, BlockPos pos, NBTTagCompound tag) {
        NetworkNode node = (NetworkNode) API.instance().getNetworkNodeRegistry().get(tag.func_74779_i(NBT_NODE_ID)).create(tag.func_74775_l(NBT_NODE), world, pos);
        node.setThrottlingDisabled();

        INetworkNodeManager manager = API.instance().getNetworkNodeManager(world);

        manager.setNode(pos, node);
        manager.markForSaving();

        Block block = Block.field_149771_c.func_82594_a(new ResourceLocation(tag.func_74779_i(NBT_BLOCK)));
        world.func_175656_a(pos, block.func_176203_a(tag.func_74762_e(NBT_META)));

        TileEntity tile = world.func_175625_s(pos);
        if (tile instanceof TileNode) {
            ((TileNode) tile).setDirection(EnumFacing.func_82600_a(tag.func_74762_e(NBT_DIRECTION)));

            tile.func_70296_d();
        }

        return true;
    }
}